-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2023 at 11:13 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `learningmanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `Email`, `UserName`, `Password`, `Image`) VALUES
(1, 'admin@gmail.com', 'Admin', 'admin1234', 'C:\\xampp\\htdocs\\learningManagementSystem\\images.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `assignment_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `courseCategory` varchar(255) NOT NULL,
  `courseId` int(11) NOT NULL,
  `date` date NOT NULL,
  `pdf` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`assignment_id`, `title`, `courseCategory`, `courseId`, `date`, `pdf`) VALUES
(6, 'Responsive Template', '2', 31, '2022-01-30', '../files/76535article.pdf'),
(9, 'Front Desk', '1', 29, '2022-02-09', '../files/365144article.pdf'),
(10, 'Basic PHP', '1', 30, '2022-02-10', '../files/376000article.pdf'),
(11, 'Php with MySQL', '1', 30, '2022-02-10', '../files/641683article.pdf'),
(12, 'Mobile Design', '2', 31, '2022-02-13', '../files/223187article.pdf'),
(13, 'Android Development', '2', 32, '2022-02-15', '../files/497897article.pdf'),
(14, 'Mobile Design with java', '2', 32, '2022-02-15', '../files/110605article.pdf'),
(15, 'The Data Warehouse', '3', 33, '2022-02-15', '../files/898230article.pdf'),
(16, 'Graphic Toolkit', '3', 33, '2022-02-16', '../files/530732article.pdf'),
(17, 'Toolkit Colors', '3', 34, '2022-02-16', '../files/270904article.pdf'),
(18, 'Graphic design', '3', 34, '2022-02-18', '../files/31459article.pdf'),
(19, 'Backend Programming', '1', 29, '2022-03-14', '../files/854158article.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL,
  `book_title` varchar(255) NOT NULL,
  `book_author` varchar(255) NOT NULL,
  `courseId` int(11) NOT NULL,
  `courseCategory` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `upload_pdf_book` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `book_title`, `book_author`, `courseId`, `courseCategory`, `date`, `upload_pdf_book`) VALUES
(8, 'Train To Busan', 'Thomas ', 29, '1', '2022-02-09', '../files/442072article.pdf'),
(10, 'Blinded', 'Thomas ', 30, '1', '2022-02-14', '../files/640895article.pdf'),
(11, 'Think and grow rich', 'Thomas ', 31, '2', '2022-02-14', '../files/198389article.pdf'),
(12, 'Silence', 'Thomas ', 31, '2', '2022-02-15', '../files/872141article.pdf'),
(13, 'Crawl', 'Thomas', 32, '2', '2022-02-15', '../files/906983article.pdf'),
(14, 'Train to Busan', 'Thomas', 32, '2', '2022-02-16', '../files/234155article.pdf'),
(15, 'Warehouse', 'Thomas ', 33, '3', '2022-02-16', '../files/256618article.pdf'),
(16, 'Graphic Learning', 'Thomas ', 33, '3', '2022-02-15', '../files/524692article.pdf'),
(17, 'Learn and Earn', 'Thomas ', 34, '3', '2022-02-23', '../files/269064article.pdf'),
(18, 'Graphic World', 'Thomas ', 34, '3', '2022-02-16', '../files/250256article.pdf'),
(19, 'Learn and Earn', 'Thomas ', 29, '1', '2022-03-14', '../files/627208article.pdf'),
(20, 'Crawl', 'Thomas ', 30, '1', '2022-03-14', '../files/802628article.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `courseId` int(11) NOT NULL,
  `courseName` varchar(255) NOT NULL,
  `courseCategory` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`courseId`, `courseName`, `courseCategory`, `thumbnail`, `description`) VALUES
(29, 'WEB DESIGNING', '1', '../images/uploads/334664download.jpg', 'Web design refers to the design of websites that are displayed on the internet. It usually refers to the user experience aspects of website development rather than software development. Web design used to be focused on designing websites for desktop '),
(30, 'FULL STACK DEVELOPMENT', '1', '../images/uploads/842184pojmovi-u-web-dizajnu.jpg', 'The full stack developer definition is “someone who can work on both the back-end and front-end of systems.” This means that they can develop fully fledged platforms (with databases, servers and clients) which don’t need other applications to functio'),
(31, 'MOBILE APP DESIGNING', '2', '../images/uploads/491720istockphoto-1218511457-612x612.jpg', 'Mobile app design encompasses both the user interface (UI) and user experience (UX). Designers are responsible for the overall style of the app, including things like the colour scheme, font selection, and the types of buttons and widgets the user wi'),
(32, 'JAVA FOR ANDROID', '2', '../images/uploads/23305how-to-get-a-job-of-an-android-developer-being-a-fresher.jpg', 'Java is the technology of choice for building applications using managed code that can execute on mobile devices.\r\n\r\nAndroid is an open source software platform and Linux-based operating system for mobile devices. The Android platform allows develope'),
(33, 'Graphic Design', '3', '../images/uploads/9114166bxva8dmzvnj8kavrqzzmp.jpg', 'Graphic design is a craft where professionals create visual content to communicate messages. By applying visual hierarchy and page layout techniques, designers use typography and pictures to meet users’ specific needs and focus on the logic of displa'),
(34, 'Fundamental Of Graphic Design', '3', '../images/uploads/75794download(2).jpg', 'The fundamentals of graphic design are about seeing (and understanding) how the qualities of visual material—shapes, images, color theory, typography, and layout—work, and work together… and then being able to decide which qualities of each are relev');

-- --------------------------------------------------------

--
-- Table structure for table `course_category`
--

CREATE TABLE `course_category` (
  `courseCategoryId` int(11) NOT NULL,
  `courseCategory` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_category`
--

INSERT INTO `course_category` (`courseCategoryId`, `courseCategory`) VALUES
(1, 'Web Development'),
(2, 'Android Development'),
(3, 'Graphic Designing');

-- --------------------------------------------------------

--
-- Table structure for table `course_uploaded_teacher`
--

CREATE TABLE `course_uploaded_teacher` (
  `id` int(11) NOT NULL,
  `UserType` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `teacher_id` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_uploaded_teacher`
--

INSERT INTO `course_uploaded_teacher` (`id`, `UserType`, `courseId`, `teacher_id`) VALUES
(3, 2, 21, '33');

-- --------------------------------------------------------

--
-- Table structure for table `pending_teacher`
--

CREATE TABLE `pending_teacher` (
  `teacher_id` int(11) NOT NULL,
  `UserName` varchar(765) DEFAULT NULL,
  `Email` varchar(765) DEFAULT NULL,
  `Password` varchar(765) DEFAULT NULL,
  `Education` varchar(765) DEFAULT NULL,
  `Image` varchar(765) DEFAULT NULL,
  `pdf_file_cv` varchar(765) DEFAULT NULL,
  `description` varchar(765) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pending_teacher`
--

INSERT INTO `pending_teacher` (`teacher_id`, `UserName`, `Email`, `Password`, `Education`, `Image`, `pdf_file_cv`, `description`) VALUES
(11, 'Ahsan Kamran', 'ahsan266@gmail.com', 'ahsan123', 'Computer Science', '../../learningManagementSystem/images/uploads/114999png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', '../../learningManagementSystem/files/444299resume.pdf', 'hello'),
(13, 'Soha Shah', 'soharashdi44@gmail.com', 'rashdi123', 'Information Technology', '../../learningManagementSystem/images/uploads/998081images.jpg', '../../learningManagementSystem/files/490355resume.pdf', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `semesterId` int(11) NOT NULL,
  `semesterName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`semesterId`, `semesterName`) VALUES
(1, 'First Semester'),
(2, 'Second Semester'),
(5, 'Third Semester'),
(6, 'Fourth Semester'),
(7, 'Fifth Semester'),
(8, 'Sixth Semester'),
(9, 'Seventh Semester'),
(10, 'Eighth Semester');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `education` varchar(255) NOT NULL,
  `courseCategory` varchar(255) NOT NULL,
  `courseId` int(11) NOT NULL,
  `semester` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `UserName`, `email`, `password`, `education`, `courseCategory`, `courseId`, `semester`, `image`) VALUES
(6, 'Aafaq Ahmed', 'CS-19-001@salu.edu.pk', 'asd.2691', 'Computer Science', '1', 29, 'Seventh', '../images/uploads/723332download (2).jpg'),
(7, 'Abdul Hafeez', 'CS-19-002@salu.edu.pk', 'asd.2692', 'Computer Science', '1', 29, 'Seventh', '../images/uploads/992247download (2).jpg'),
(8, 'Abdul Haseeb', 'CS-19-003@salu.edu.pk', 'asd.2693', 'Computer Science', '1', 29, 'Seventh', '../images/uploads/558558download (2).jpg'),
(9, 'Abdul Haseeb', 'CS-19-004@salu.edu.pk', 'asd.2694', 'Computer Science', '1', 29, 'Seventh', '../images/uploads/751724download (2).jpg'),
(10, 'Abdul Raouf', 'CS-19-005@salu.edu.pk', 'asd.2695', 'Computer Science', '1', 30, 'Seventh', '../images/uploads/155505download (2).jpg'),
(11, 'Abdul Sami', 'CS-19-006@salu.edu.pk', 'asd.2696', 'Computer Science', '1', 29, 'Seventh', '../images/uploads/837119download (2).jpg'),
(12, 'Aftab Anwar', 'CS-19-007@salu.edu.pk', 'asd.2697', 'Computer Science', '1', 29, 'Seventh', '../images/uploads/10178download (2).jpg'),
(13, 'Ahsan Ali', 'CS-19-008@salu.edu.pk', 'asd.2698', 'Computer Science', '1', 30, 'Seventh', '../images/uploads/340040download (2).jpg'),
(14, 'Aizaz Ahmed', 'CS-19-009@salu.edu.pk', 'asd.2699', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/378003download (2).jpg'),
(15, 'Aqsa Batool', 'CS-19-010@salu.edu.pk', 'asd.2700', 'Computer Science', '2', 32, 'Seventh', '../images/uploads/530980images.jpg'),
(16, 'Arsalan Javed', 'CS-19-011@salu.edu.pk', 'asd.2701', 'Computer Science', '2', 32, 'Seventh', '../images/uploads/616066download (2).jpg'),
(17, 'Arslan Razzaq', 'CS-19-012@salu.edu.pk', 'asd.2702', 'Computer Science', '3', 33, 'Seventh', '../images/uploads/616987download (2).jpg'),
(18, 'Asadullah', 'CS-19-013@salu.edu.pk', 'asd.2703', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/873079download (2).jpg'),
(19, 'Aun Muhammad', 'CS-19-014@salu.edu.pk', 'asd.2704', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/548284download (2).jpg'),
(20, 'Ayaz Ali', 'CS-19-015@salu.edu.pk', 'asd.2705', 'Computer Science', '2', 32, 'Seventh', '../images/uploads/726839download (2).jpg'),
(21, 'Ayaz Gul', 'CS-19-016@salu.edu.pk', 'asd.2706', 'Computer Science', '2', 32, 'Seventh', '../images/uploads/738587download (2).jpg'),
(22, 'Ayesha Farooq', 'CS-19-017@salu.edu.pk', 'asd.2707', 'Computer Science', '1', 30, 'Seventh', '../images/uploads/689578images.jpg'),
(23, 'Badar Uddin', 'CS-19-018@salu.edu.pk', 'asd.2708', 'Computer Science', '1', 29, 'Seventh', '../images/uploads/703558download (2).jpg'),
(24, 'Bakhtawar', 'CS-19-019@salu.edu.pk', 'asd.2709', 'Computer Science', '1', 30, 'Seventh', '../images/uploads/628972images.jpg'),
(25, 'Faisal Khan', 'CS-19-020@salu.edu.pk', 'asd.2710', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/770540download (2).jpg'),
(26, 'Faisal Mukhtiar', 'CS-19-021@salu.edu.pk', 'asd.2711', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/593954download (2).jpg'),
(27, 'Fiaz Ahmed', 'CS-19-022@salu.edu.pk', 'asd.2712', 'Computer Science', '2', 32, 'Seventh', '../images/uploads/398963download (2).jpg'),
(28, 'Ghulam Mahdi', 'CS-19-023@salu.edu.pk', 'asd.2713', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/261710download (2).jpg'),
(29, 'Haleema Batool', 'CS-19-024@salu.edu.pk', 'asd.2714', 'Computer Science', '3', 33, 'Seventh', '../images/uploads/144669images.jpg'),
(30, 'Hamza Ali', 'CS-19-025@salu.edu.pk', 'asd.2715', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/401007download (2).jpg'),
(31, 'Hina Yaqoub', 'CS-19-026@salu.edu.pk', 'asd.2716', 'Computer Science', '2', 32, 'Seventh', '../images/uploads/70737images.jpg'),
(32, 'Iqra Naz', 'CS-19-027@salu.edu.pk', 'asd.2717', 'Computer Science', '2', 32, 'Seventh', '../images/uploads/101953images.jpg'),
(33, 'Ishfaque Ahmed', 'CS-19-028@salu.edu.pk', 'asd.2718', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/874597download (2).jpg'),
(34, 'Jamila', 'CS-19-029@salu.edu.pk', 'asd.2719', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/385886images.jpg'),
(35, 'Jhanzeb', 'CS-19-030@salu.edu.pk', 'asd.2720', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/465594download (2).jpg'),
(36, 'Khuda Bux', 'CS-19-031@salu.edu.pk', 'asd.2721', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/771486download (2).jpg'),
(37, 'Mir Muhammad Alias Shahid Hussain', 'CS-19-032@salu.edu.pk', 'asd.2722', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/255817download (2).jpg'),
(38, 'Muhammad Ali Naqi', 'CS-19-033@salu.edu.pk', 'asd.2723', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/190943download (2).jpg'),
(39, 'Muhammad Azam', 'CS-19-034@salu.edu.pk', 'asd.2724', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/30690download (2).jpg'),
(40, 'Muhammad Faheem', 'CS-19-035@salu.edu.pk', 'asd.2725', 'Computer Science', '3', 33, 'Seventh', '../images/uploads/733371download (2).jpg'),
(41, 'Muhammad Rashid', 'CS-19-036@salu.edu.pk', 'asd.2726', 'Computer Science', '3', 33, 'Seventh', '../images/uploads/803433download (2).jpg'),
(42, 'Muhammad Umar Farooq', 'CS-19-037@salu.edu.pk', 'asd.2727', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/922109download (2).jpg'),
(43, 'Muhammad Usama', 'CS-19-038@salu.edu.pk', 'asd.2728', 'Computer Science', '1', 30, 'Seventh', '../images/uploads/708677download (2).jpg'),
(44, 'Muhammad Usman', 'CS-19-039@salu.edu.pk', 'asd.2729', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/754578download (2).jpg'),
(45, 'Muhammad Waseem', 'CS-19-040@salu.edu.pk', 'asd.2730', 'Computer Science', '2', 32, 'Seventh', '../images/uploads/414404download (2).jpg'),
(46, 'Muhanmmad Aaqib', 'CS-19-041@salu.edu.pk', 'asd.2731', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/308622download (2).jpg'),
(47, 'Mujahid Hussain', 'CS-19-042@salu.edu.pk', 'asd.2732', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/623592download (2).jpg'),
(48, 'Numan Ali', 'CS-19-043@salu.edu.pk', 'asd.2733', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/552136download (2).jpg'),
(49, 'Sadaqat Ali', 'CS-19-044@salu.edu.pk', 'asd.2734', 'Computer Science', '1', 29, 'Seventh', '../images/uploads/626712download (2).jpg'),
(50, 'Sanjay Kumar', 'CS-19-045@salu.edu.pk', 'asd.2735', 'Computer Science', '2', 30, 'Seventh', '../images/uploads/824885download (2).jpg'),
(51, 'Sarfraz Ali', 'CS-19-046@salu.edu.pk', 'asd.2736', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/934571download (2).jpg'),
(52, 'Shams Uddn', 'CS-19-047@salu.edu.pk', 'asd.2737', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/645903download (2).jpg'),
(53, 'Shauban Ali', 'CS-19-048@salu.edu.pk', 'asd.2738', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/82638download (2).jpg'),
(54, 'Shifayatullah', 'CS-19-049@salu.edu.pk', 'asd.2739', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/418151download (2).jpg'),
(55, 'Siraj U Din', 'CS-19-050@salu.edu.pk', 'asd.2740', 'Computer Science', '2', 32, 'Seventh', '../images/uploads/700819download (2).jpg'),
(56, 'Sudheer Ahmed', 'CS-19-051@salu.edu.pk', 'asd.2741', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/357623download (2).jpg'),
(57, 'Suhail Ahmed', 'CS-19-052@salu.edu.pk', 'asd.2742', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/142185download (2).jpg'),
(58, 'Syeda Mubashara Batool', 'CS-19-053@salu.edu.pk', 'asd.2743', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/348852images.jpg'),
(59, 'Umair Hussain', 'CS-19-054@salu.edu.pk', 'asd.2744', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/934359download (2).jpg'),
(60, 'Wajid Ali', 'CS-19-055@salu.edu.pk', 'asd.2745', 'Computer Science', '1', 30, 'Seventh', '../images/uploads/791332download (2).jpg'),
(61, 'Waqar Ahmed', 'CS-19-056@salu.edu.pk', 'asd.2746', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/365504download (2).jpg'),
(62, 'Zeeshan Ahmed', 'CS-19-057@salu.edu.pk', 'asd.2747', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/147873download (2).jpg'),
(63, 'Zeeshan Ali', 'CS-19-058@salu.edu.pk', 'asd.2748', 'Computer Science', '3', 31, 'Seventh', '../images/uploads/649647download (2).jpg'),
(64, 'Zeeshan Ali', 'CS-19-059@salu.edu.pk', 'asd.2749', 'Computer Science', '3', 34, 'Seventh', '../images/uploads/175759download (2).jpg'),
(65, 'Zubair Ahmed', 'CS-19-060@salu.edu.pk', 'asd.2750', 'Computer Science', '1', 30, 'Seventh', '../images/uploads/583616download (2).jpg'),
(66, 'Zubair Hussain', 'CS-19-061@salu.edu.pk', 'asd.2751', 'Computer Science', '1', 30, 'Seventh', '../images/uploads/528944download (2).jpg'),
(67, 'Zulfiqar Ahmed', 'CS-19-062@salu.edu.pk', 'asd.2752', 'Computer Science', '1', 29, 'Seventh', '../images/uploads/642766download (2).jpg'),
(68, 'Abdur Rehman Khan', 'CS-19-063@salu.edu.pk', 'asd.2753', 'Computer Science', '1', 30, 'Seventh', '../images/uploads/776720download (2).jpg'),
(69, 'Tallat Hussain', 'CS-19-064@salu.edu.pk', 'asd.2754', 'Computer Science', '2', 31, 'Seventh', '../images/uploads/143270download (2).jpg'),
(70, 'Abdul Hayee', 'CS-19-065@salu.edu.pk', 'asd.10062', 'Computer Science', '3', 33, 'Seventh', '../images/uploads/438467download (2).jpg'),
(72, 'Aafaque Ahmed', 'CS-20-001@salu.edu.pk', 'asd.2755', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/875632png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(73, 'Abdul Fatah', 'CS-20-002@salu.edu.pk', 'asd.2756', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/717726png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(74, 'Abdul Kareem', 'CS-20-003@salu.edu.pk', 'asd.2757', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/464519png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(75, 'Adnan Aijaz', 'CS-20-004@salu.edu.pk', 'asd.2758', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/584806png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(76, 'Afzal Hussain', 'CS-20-005@salu.edu.pk', 'asd.2759', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/314369png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(77, 'Akbar Khan', 'CS-20-006@salu.edu.pk', 'asd.2760', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/253040png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(78, 'Ali Hyder', 'CS-20-007@salu.edu.pk', 'asd.2761', 'Computer Science', '2', 32, 'Fifth', '../images/uploads/191955png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(79, 'Ali Hyder Shah', 'CS-20-008@salu.edu.pk', 'asd.2762', 'Computer Science', '3', 33, 'Fifth', '../images/uploads/971971png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(80, 'Alqa Saeed', 'CS-20-009@salu.edu.pk', 'asd.2763', 'Computer Science', '3', 34, 'Fifth', '../images/uploads/317437png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(81, 'Amir Ali', 'CS-20-010@salu.edu.pk', 'asd.2764', 'Computer Science', '3', 33, 'Fifth', '../images/uploads/720970png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(82, 'Ammar Ali', 'CS-20-011@salu.edu.pk', 'asd.2765', 'Computer Science', '2', 32, 'Fifth', '../images/uploads/656952png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(83, 'Amna', 'CS-20-012@salu.edu.pk', 'asd.2766', 'Computer Science', '3', 34, 'Fifth', '../images/uploads/950963images.jpg'),
(84, 'Arshad Ali', 'CS-20-013@salu.edu.pk', 'asd.2767', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/999128png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(85, 'Ashraf Ali', 'CS-20-014@salu.edu.pk', 'asd.2768', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/322039png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(86, 'Asif Ali', 'CS-20-015@salu.edu.pk', 'asd.2769', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/563406png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(87, 'Aurangzeb Shah', 'CS-20-016@salu.edu.pk', 'asd.2770', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/840416png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(88, 'Bushra', 'CS-20-017@salu.edu.pk', 'asd.2771', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/195491images.jpg'),
(89, 'Deedar Ali', 'CS-20-018@salu.edu.pk', 'asd.2772', 'Computer Science', '2', 32, 'Fifth', '../images/uploads/834549png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(90, 'Dua', 'CS-20-019@salu.edu.pk', 'asd.2773', 'Computer Science', '2', 32, 'Fifth', '../images/uploads/655201images.jpg'),
(91, 'Fahad Ali', 'CS-20-020@salu.edu.pk', 'asd.2774', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/810385png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(92, 'Ghulam Muhayadin', 'CS-20-021@salu.edu.pk', 'asd.2775', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/56892png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(93, 'Ghulam Mujtaba', 'CS-20-022@salu.edu.pk', 'asd.2776', 'Computer Science', '2', 32, 'Fifth', '../images/uploads/217205png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(94, 'Hadeeqa Naz', 'CS-20-023@salu.edu.pk', 'asd.2777', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/806639images.jpg'),
(95, 'Husnain', 'CS-20-024@salu.edu.pk', 'asd.2778', 'Computer Science', '2', 32, 'Fifth', '../images/uploads/945224png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(96, 'Hyder Ali', 'CS-20-025@salu.edu.pk', 'asd.2779', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/511921png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(97, 'Ilsa Agha', 'CS-20-026@salu.edu.pk', 'asd.2780', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/411187images.jpg'),
(98, 'Ilyas Ahmed', 'CS-20-027@salu.edu.pk', 'asd.2781', 'Computer Science', '3', 34, 'Fifth', '../images/uploads/537393png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(99, 'Imam Bux', 'CS-20-028@salu.edu.pk', 'asd.2782', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/257046png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(100, 'Imdad Ali', 'CS-20-029@salu.edu.pk', 'asd.2783', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/845598png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(101, 'Kaleemullah', 'CS-20-030@salu.edu.pk', 'asd.2784', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/165151png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(102, 'Kumail Raza', 'CS-20-031@salu.edu.pk', 'asd.2785', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/119663png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(103, 'Mahnoor', 'CS-20-032@salu.edu.pk', 'asd.2786', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/881418images.jpg'),
(104, 'Mansoor Alam', 'CS-20-033@salu.edu.pk', 'asd.2787', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/320140png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(105, 'Mehr Un Nisa', 'CS-20-034@salu.edu.pk', 'asd.2788', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/866582images.jpg'),
(106, 'Mir Akbar Raza', 'CS-20-035@salu.edu.pk', 'asd.2789', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/376632png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(107, 'Mir Haider Raza', 'CS-20-036@salu.edu.pk', 'asd.2790', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/445885png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(108, 'Mirza Muhammad Ammar Baig', 'CS-20-037@salu.edu.pk', 'asd.2791', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/391703png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(109, 'Muammad Irfan', 'CS-20-038@salu.edu.pk', 'asd.2792', 'Computer Science', '2', 30, 'Fifth', '../images/uploads/649783png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(110, 'Mudasir Ali', 'CS-20-039@salu.edu.pk', 'asd.2793', 'Computer Science', '2', 32, 'Fifth', '../images/uploads/510756png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(111, 'Muhammad Ibrahim', 'CS-20-040@salu.edu.pk', 'asd.2794', 'Computer Science', '3', 33, 'Fifth', '../images/uploads/851114png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(112, 'Muhammad Mustaqeem', 'CS-20-041@salu.edu.pk', 'asd.2795', 'Computer Science', '2', 30, 'Fifth', '../images/uploads/956376png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(113, 'Muhammad Tahir', 'CS-20-042@salu.edu.pk', 'asd.2796', 'Computer Science', '2', 32, 'Fifth', '../images/uploads/132733png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(114, 'Munwar Hussain', 'CS-20-043@salu.edu.pk', 'asd.2797', 'Computer Science', '3', 33, 'Fifth', '../images/uploads/89414png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(115, 'Murk', 'CS-20-044@salu.edu.pk', 'asd.2798', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/522858images.jpg'),
(116, 'Nazeer Ahmed', 'CS-20-045@salu.edu.pk', 'asd.2799', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/715868png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(117, 'Noman Ali', 'CS-20-046@salu.edu.pk', 'asd.2800', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/17340png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(118, 'Noor Mustafa', 'CS-20-047@salu.edu.pk', 'asd.2801', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/511072png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(119, 'Qandeel', 'CS-20-048@salu.edu.pk', 'asd.2802', 'Computer Science', '3', 34, 'Fifth', '../images/uploads/819144png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(120, 'Rizwan Memon', 'CS-20-049@salu.edu.pk', 'asd.2803', 'Computer Science', '2', 30, 'Fifth', '../images/uploads/352845png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(121, 'Saba', 'CS-20-050@salu.edu.pk', 'asd.2804', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/597265images.jpg'),
(122, 'Saifullah', 'CS-20-051@salu.edu.pk', 'asd.2805', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/378286png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(123, 'Sajjad Ali', 'CS-20-052@salu.edu.pk', 'asd.2806', 'Computer Science', '3', 30, 'Fifth', '../images/uploads/961010png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(124, 'Sanaullah', 'CS-20-053@salu.edu.pk', 'asd.2807', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/868164png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(125, 'Sankesh Lal', 'CS-20-054@salu.edu.pk', 'asd.2808', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/870471png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(126, 'Shabnam', 'CS-20-055@salu.edu.pk', 'asd.2809', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/408664images.jpg'),
(127, 'Sheeraz Ahmed', 'CS-20-056@salu.edu.pk', 'asd.2810', 'Computer Science', '3', 34, 'Fifth', '../images/uploads/370472png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(128, 'Shiza Fatima', 'CS-20-057@salu.edu.pk', 'asd.2811', 'Computer Science', '2', 32, 'Fifth', '../images/uploads/646584images.jpg'),
(129, 'Shoaib Hassan', 'CS-20-058@salu.edu.pk', 'asd.2812', 'Computer Science', '2', 30, 'Fifth', '../images/uploads/637203png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(130, 'Sibghatullah', 'CS-20-059@salu.edu.pk', 'asd.2813', 'Computer Science', '2', 30, 'Fifth', '../images/uploads/861446png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(131, 'Simran Kumari', 'CS-20-060@salu.edu.pk', 'asd.2814', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/907677images.jpg'),
(132, 'Siraj Ali', 'CS-20-061@salu.edu.pk', 'asd.2815', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/137893png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(133, 'Sobia Siraj', 'CS-20-062@salu.edu.pk', 'asd.2816', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/765686images.jpg'),
(134, 'Sultan Ahmed', 'CS-20-063@salu.edu.pk', 'asd.2817', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/737232png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(135, 'Syed Shakeel Abbas Shah', 'CS-20-064@salu.edu.pk', 'asd.2818', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/943769png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(136, 'Syeda Iqra Batool', 'CS-20-065@salu.edu.pk', 'asd.2819', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/741105images.jpg'),
(137, 'Tanzeel Ur Rehman', 'CS-20-066@salu.edu.pk', 'asd.2820', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/432361png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(138, 'Toheed Gul', 'CS-20-067@salu.edu.pk', 'asd.2821', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/820202png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(139, 'Toufique Ahmed', 'CS-20-068@salu.edu.pk', 'asd.2822', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/565864png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(140, 'Tuba', 'CS-20-069@salu.edu.pk', 'asd.2823', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/447945png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(141, 'Turab Mahdi', 'CS-20-070@salu.edu.pk', 'asd.2824', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/116913download (2).jpg'),
(142, 'Ubedullah', 'CS-20-071@salu.edu.pk', 'asd.2825', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/714929png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(143, 'Ubedullah', 'CS-20-072@salu.edu.pk', 'asd.2826', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/116114png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(144, 'Waniya Mukhtiar', 'CS-20-073@salu.edu.pk', 'asd.2827', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/686233images.jpg'),
(145, 'Yasir Ali', 'CS-20-074@salu.edu.pk', 'asd.2828', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/623990png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(146, 'Zohaib Ahmed', 'CS-20-075@salu.edu.pk', 'asd.2829', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/57918png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(147, 'Zuhaib Ahmed', 'CS-20-076@salu.edu.pk', 'asd.2830', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/250009png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(148, 'Abdul Basit', 'CS-20-077@salu.edu.pk', 'asd.9560', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/127365png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(149, 'Nadir Ali', 'CS-20-078@salu.edu.pk', 'asd.9561', 'Computer Science', '2', 31, 'Fifth', '../images/uploads/203335png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(150, 'Salamat Ali', 'CS-20-079@salu.edu.pk', 'asd.9562', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/253171png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(151, 'Tahir Hussain Shar', 'CS-20-080@salu.edu.pk', 'asd.9797', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/730131png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(152, 'Shakir Hussain', 'CS-20-081@salu.edu.pk', 'asd.9798', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/221494png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(153, 'Asmatullah', 'CS-20-082@salu.edu.pk', 'asd.10057', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/771211png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(154, 'Mehdi Abbas', 'CS-20-083@salu.edu.pk', 'asd.10064', 'Computer Science', '1', 30, 'Fifth', '../images/uploads/287325png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(155, 'Sarfaraz Ali', 'CS-20-084@salu.edu.pk', 'asd.10136', 'Computer Science', '1', 29, 'Fifth', '../images/uploads/704789png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(156, 'Abdul Ahad', 'IT-19-001@salu.edu.pk', 'asd.5062', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/516635png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(157, 'Abdul Hayee', 'IT-19-002@salu.edu.pk', 'asd.5063', 'Information Technology', '1', 30, 'Seventh', '../images/uploads/652156download (2).jpg'),
(158, 'Abdul Khalique', 'IT-19-003@salu.edu.pk', 'asd.5064', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/991811png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png'),
(159, 'Abdul Malik', 'IT-19-004@salu.edu.pk', 'asd.5065', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/721380download (2).jpg'),
(160, 'Abdul Rafiu', 'IT-19-005@salu.edu.pk', 'asd.5066', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/192671download (2).jpg'),
(161, 'Abdul Rahman', 'IT-19-006@salu.edu.pk', 'asd.5067', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/297748download (2).jpg'),
(162, 'Abdul Samad', 'IT-19-007@salu.edu.pk', 'asd.5068', 'Information Technology', '3', 33, 'Seventh', '../images/uploads/951958download (2).jpg'),
(163, 'Abdul Sami', 'IT-19-008@salu.edu.pk', 'asd.5069', 'Information Technology', '2', 32, 'Seventh', '../images/uploads/150943download (2).jpg'),
(164, 'Abid Raza', 'IT-19-009@salu.edu.pk', 'asd.5070', 'Information Technology', '3', 33, 'Seventh', '../images/uploads/983481download (2).jpg'),
(165, 'Abuzar Mehdi', 'IT-19-010@salu.edu.pk', 'asd.5071', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/530795download (2).jpg'),
(166, 'Adnan Ali', 'IT-19-011@salu.edu.pk', 'asd.5072', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/230368download (2).jpg'),
(167, 'Afifa', 'IT-19-012@salu.edu.pk', 'asd.5073', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/238927images.jpg'),
(168, 'Aftab', 'IT-19-013@salu.edu.pk', 'asd.5074', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/418136download (2).jpg'),
(169, 'Akhtar Ali', 'IT-19-014@salu.edu.pk', 'asd.5075', 'Information Technology', '2', 30, 'Seventh', '../images/uploads/826293download (2).jpg'),
(170, 'Ali Gul', 'IT-19-015@salu.edu.pk', 'asd.5076', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/960656download (2).jpg'),
(171, 'Ali Murad', 'IT-19-016@salu.edu.pk', 'asd.5077', 'Information Technology', '2', 30, 'Seventh', '../images/uploads/449804download (2).jpg'),
(172, 'Ameer Haider', 'IT-19-017@salu.edu.pk', 'asd.5078', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/430433download (2).jpg'),
(173, 'Ameer Ul Azeem', 'IT-19-018@salu.edu.pk', 'asd.5079', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/738340download (2).jpg'),
(174, 'Ansar Ali', 'IT-19-019@salu.edu.pk', 'asd.5080', 'Information Technology', '2', 32, 'Seventh', '../images/uploads/841125download (2).jpg'),
(175, 'Aqib Hussain', 'IT-19-020@salu.edu.pk', 'asd.5081', 'Information Technology', '2', 30, 'Seventh', '../images/uploads/460462download (2).jpg'),
(176, 'Arham Ali Agha', 'IT-19-021@salu.edu.pk', 'asd.5082', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/804287download (2).jpg'),
(177, 'Babar Ali', 'IT-19-022@salu.edu.pk', 'asd.5083', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/536081download (2).jpg'),
(178, 'Faraz Ahmed', 'IT-19-023@salu.edu.pk', 'asd.5084', 'Information Technology', '1', 30, 'Seventh', '../images/uploads/775231download (2).jpg'),
(179, 'Faraz Asif', 'IT-19-024@salu.edu.pk', 'asd.5085', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/657900download (2).jpg'),
(180, 'Farhan Ali', 'IT-19-025@salu.edu.pk', 'asd.5086', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/798111download (2).jpg'),
(181, 'Fazeela Gul', 'IT-19-026@salu.edu.pk', 'asd.5087', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/570784images.jpg'),
(182, 'Ghulam Shabeer', 'IT-19-027@salu.edu.pk', 'asd.5088', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/508850download (2).jpg'),
(183, 'Gunwanti Devi', 'IT-19-028@salu.edu.pk', 'asd.5089', 'Information Technology', '3', 33, 'Seventh', '../images/uploads/755680images.jpg'),
(184, 'Hamza Ahmed', 'IT-19-029@salu.edu.pk', 'asd.5090', 'Information Technology', '2', 32, 'Seventh', '../images/uploads/102651download (2).jpg'),
(185, 'Hasnain Ali', 'IT-19-030@salu.edu.pk', 'asd.5091', 'Information Technology', '3', 33, 'Seventh', '../images/uploads/92356download (2).jpg'),
(186, 'Imran Hussain', 'IT-19-031@salu.edu.pk', 'asd.5092', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/247807download (2).jpg'),
(187, 'Inam Ali Shah', 'IT-19-032@salu.edu.pk', 'asd.5093', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/762567download (2).jpg'),
(188, 'Ishtiaque Hussain', 'IT-19-033@salu.edu.pk', 'asd.5094', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/718931download (2).jpg'),
(189, 'Izhar Ali', 'IT-19-034@salu.edu.pk', 'asd.5095', 'Information Technology', '3', 33, 'Seventh', '../images/uploads/67568download (2).jpg'),
(190, 'Jindal Gul', 'IT-19-035@salu.edu.pk', 'asd.5096', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/986043download (2).jpg'),
(191, 'Kamran Ali', 'IT-19-036@salu.edu.pk', 'asd.5097', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/306226download (2).jpg'),
(192, 'Kashif Ali', 'IT-19-037@salu.edu.pk', 'asd.5098', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/868834download (2).jpg'),
(193, 'Khalil Ahmed', 'IT-19-038@salu.edu.pk', 'asd.5099', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/18261download (2).jpg'),
(194, 'Mahmood Hasnain', 'IT-19-039@salu.edu.pk', 'asd.5100', 'Information Technology', '1', 30, 'Seventh', '../images/uploads/761903download (2).jpg'),
(195, 'Mahmood Khan', 'IT-19-040@salu.edu.pk', 'asd.5101', 'Information Technology', '2', 32, 'Seventh', '../images/uploads/626942download (2).jpg'),
(196, 'Manik', 'IT-19-041@salu.edu.pk', 'asd.5102', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/384944download (2).jpg'),
(197, 'Mir Raza Ali', 'IT-19-042@salu.edu.pk', 'asd.5103', 'Information Technology', '2', 32, 'Seventh', '../images/uploads/32218download (2).jpg'),
(198, 'Muhammad Ali', 'IT-19-043@salu.edu.pk', 'asd.5104', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/748829download (2).jpg'),
(199, 'Muhammad Aqib', 'IT-19-044@salu.edu.pk', 'asd.5105', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/483562download (2).jpg'),
(200, 'Muhammad Ayoub', 'IT-19-045@salu.edu.pk', 'asd.5106', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/845776download (2).jpg'),
(201, 'Muhammad Usman', 'IT-19-046@salu.edu.pk', 'asd.5107', 'Information Technology', '1', 30, 'Seventh', '../images/uploads/929128download (2).jpg'),
(202, 'Muhammad Waseem', 'IT-19-047@salu.edu.pk', 'asd.5108', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/761380download (2).jpg'),
(203, 'Muneer Hussain', 'IT-19-048@salu.edu.pk', 'asd.5109', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/345039download (2).jpg'),
(204, 'Muqadas Sadia', 'IT-19-049@salu.edu.pk', 'asd.5110', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/297016download (2).jpg'),
(205, 'Qutib Ali', 'IT-19-050@salu.edu.pk', 'asd.5111', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/180219download (2).jpg'),
(206, 'Rameez Raja', 'IT-19-051@salu.edu.pk', 'asd.5112', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/209874download (2).jpg'),
(207, 'Rehman Abid', 'IT-19-052@salu.edu.pk', 'asd.5113', 'Information Technology', '1', 30, 'Seventh', '../images/uploads/867750download (2).jpg'),
(208, 'Rizwan Ali', 'IT-19-053@salu.edu.pk', 'asd.5114', 'Information Technology', '2', 32, 'Seventh', '../images/uploads/468573download (2).jpg'),
(209, 'Sadaqat Nawaz', 'IT-19-054@salu.edu.pk', 'asd.5115', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/60495download (2).jpg'),
(210, 'Sagar Rai', 'IT-19-055@salu.edu.pk', 'asd.5116', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/684140download (2).jpg'),
(211, 'Salma', 'IT-19-056@salu.edu.pk', 'asd.5117', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/700241images.jpg'),
(212, 'Sameer Hussain', 'IT-19-057@salu.edu.pk', 'asd.5118', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/871734download (2).jpg'),
(213, 'Samiullah', 'IT-19-058@salu.edu.pk', 'asd.5119', 'Information Technology', '2', 31, 'Seventh', '../images/uploads/257176download (2).jpg'),
(214, 'Sarfraz Ali', 'IT-19-059@salu.edu.pk', 'asd.5120', 'Information Technology', '1', 30, 'Seventh', '../images/uploads/281107download (2).jpg'),
(216, 'Shah Zaid', 'IT-19-061@salu.edu.pk', 'asd.5122', 'Information Technology', '1', 30, 'Seventh', '../images/uploads/752490download (2).jpg'),
(217, 'Sheeraz', 'IT-19-062@salu.edu.pk', 'asd.5123', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/623672download (2).jpg'),
(218, 'Syed Farhan Ali', 'IT-19-063@salu.edu.pk', 'asd.5124', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/711140download (2).jpg'),
(219, 'Tahir Khan', 'IT-19-064@salu.edu.pk', 'asd.5125', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/878169download (2).jpg'),
(220, 'Usama', 'IT-19-065@salu.edu.pk', 'asd.5126', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/101029download (2).jpg'),
(221, 'Wajid Ali', 'IT-19-066@salu.edu.pk', 'asd.5127', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/861311download (2).jpg'),
(222, 'Wajid Hussain', 'IT-19-067@salu.edu.pk', 'asd.5128', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/143157download (2).jpg'),
(223, 'Waqar Ahmed', 'IT-19-068@salu.edu.pk', 'asd.5129', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/430504download (2).jpg'),
(224, 'Zafaruddin', 'IT-19-069@salu.edu.pk', 'asd.5130', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/514081download (2).jpg'),
(225, 'Zeeshan Ali', 'IT-19-070@salu.edu.pk', 'asd.5131', 'Information Technology', '2', 32, 'Seventh', '../images/uploads/748332download (2).jpg'),
(226, 'Zeeshan Ali', 'IT-19-071@salu.edu.pk', 'asd.5132', 'Information Technology', '1', 29, 'Seventh', '../images/uploads/266196download (2).jpg'),
(227, 'Wajid Ali', 'IT-19-072@salu.edu.pk', 'asd.10063', 'Information Technology', '3', 34, 'Seventh', '../images/uploads/848859download (2).jpg'),
(228, 'Jinsar Ali', 'IT-19-073@salu.edu.pk', 'asd.10121', 'Information Technology', '3', 34, 'Seventh', '../images/uploads/503435download (2).jpg'),
(229, 'Aamir Raza', 'IT-20-002@salu.edu.pk', 'asd.5133', 'Information Technology', '1', 30, 'Fifth', '../images/uploads/112924download (2).jpg'),
(230, 'Abdul Ghaffar', 'IT-20-003@salu.edu.pk', 'asd.5134', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/207762download (2).jpg'),
(231, 'Abdul Qadeer', 'IT-20-004@salu.edu.pk', 'asd.5135', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/143321download (2).jpg'),
(232, 'Abdul Rafai', 'IT-20-005@salu.edu.pk', 'asd.5136', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/297648download (2).jpg'),
(233, 'Abdul Rafio', 'IT-20-006@salu.edu.pk', 'asd.5137', 'Information Technology', '1', 30, 'Fifth', '../images/uploads/698274download (2).jpg'),
(234, 'Abdul Waheed', 'IT-20-007@salu.edu.pk', 'asd.5138', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/377286download (2).jpg'),
(235, 'Ahsan Hussain Tajlani', 'IT-20-008@salu.edu.pk', 'asd.5139', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/737064download (2).jpg'),
(236, 'Aiman Aslam', 'IT-20-009@salu.edu.pk', 'asd.5140', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/563289images.jpg'),
(237, 'Ali Hassan', 'IT-20-010@salu.edu.pk', 'asd.5141', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/458246download (2).jpg'),
(238, 'Ali Nawaz', 'IT-20-011@salu.edu.pk', 'asd.5142', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/555349download (2).jpg'),
(239, 'Ameer Ali', 'IT-20-012@salu.edu.pk', 'asd.5143', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/312932download (2).jpg'),
(240, 'Amna', 'IT-20-013@salu.edu.pk', 'asd.5144', 'Information Technology', '3', 33, 'Fifth', '../images/uploads/224877images.jpg'),
(241, 'Asadullah Malhar Khan Dayo', 'IT-20-014@salu.edu.pk', 'asd.5145', 'Information Technology', '3', 34, 'Fifth', '../images/uploads/249550download (2).jpg'),
(242, 'Asif Hussain', 'IT-20-016@salu.edu.pk', 'asd.5146', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/508297download (2).jpg'),
(243, 'Asmatullah', 'IT-20-017@salu.edu.pk', 'asd.5147', 'Information Technology', '3', 33, 'Fifth', '../images/uploads/141209download (2).jpg'),
(244, 'Eshwar Kumar', 'IT-20-018@salu.edu.pk', 'asd.5148', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/519045download (2).jpg'),
(245, 'Faheem Ahmed', 'IT-20-019@salu.edu.pk', 'asd.5149', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/565311download (2).jpg'),
(246, 'Faheem Ali', 'IT-20-020@salu.edu.pk', 'asd.5150', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/636570download (2).jpg'),
(247, 'Faheem Asghar', 'IT-20-021@salu.edu.pk', 'asd.5151', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/474000download (2).jpg'),
(248, 'Farman Ahmed', 'IT-20-022@salu.edu.pk', 'asd.5152', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/633831download (2).jpg'),
(249, 'Ghulam Akbar', 'IT-20-023@salu.edu.pk', 'asd.5153', 'Information Technology', '3', 33, 'Fifth', '../images/uploads/851977download (2).jpg'),
(250, 'Ghulam Fareed', 'IT-20-024@salu.edu.pk', 'asd.5154', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/43259download (2).jpg'),
(251, 'Ghulam Mujtaba', 'IT-20-025@salu.edu.pk', 'asd.5155', 'Information Technology', '3', 33, 'Fifth', '../images/uploads/90636download (2).jpg'),
(252, 'Hamzah', 'IT-20-026@salu.edu.pk', 'asd.5156', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/34766download (2).jpg'),
(253, 'Haseebullah', 'IT-20-027@salu.edu.pk', 'asd.5157', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/865594download (2).jpg'),
(254, 'Junaid Ahmed', 'IT-20-028@salu.edu.pk', 'asd.5158', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/499385download (2).jpg'),
(255, 'Khaleel Ahmed', 'IT-20-029@salu.edu.pk', 'asd.5159', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/453851download (2).jpg'),
(256, 'Kosar Ali Raza', 'IT-20-030@salu.edu.pk', 'asd.5160', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/923925download (2).jpg'),
(257, 'Mahnoor', 'IT-20-031@salu.edu.pk', 'asd.5161', 'Information Technology', '1', 30, 'Fifth', '../images/uploads/610327images.jpg'),
(258, 'Maqsar Ahmed', 'IT-20-032@salu.edu.pk', 'asd.5162', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/197690download (2).jpg'),
(259, 'Mausooma Maqsood', 'IT-20-033@salu.edu.pk', 'asd.5163', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/9259images.jpg'),
(260, 'Mir Hassan Raza', 'IT-20-034@salu.edu.pk', 'asd.5164', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/769393download (2).jpg'),
(261, 'Mir Hassnain Raza', 'IT-20-035@salu.edu.pk', 'asd.5165', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/450548download (2).jpg'),
(262, 'Mohammad Asifuddin', 'IT-20-036@salu.edu.pk', 'asd.5166', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/697738download (2).jpg'),
(263, 'Muhammad Aadil', 'IT-20-037@salu.edu.pk', 'asd.5167', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/626318download (2).jpg'),
(264, 'Muhammad Abdullah', 'IT-20-038@salu.edu.pk', 'asd.5168', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/418288download (2).jpg'),
(265, 'Muhammad Abdullah', 'IT-20-039@salu.edu.pk', 'asd.5169', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/582808download (2).jpg'),
(266, 'Muhammad Ameen', 'IT-20-040@salu.edu.pk', 'asd.5170', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/854340download (2).jpg'),
(267, 'Muhammad Madni Raza', 'IT-20-041@salu.edu.pk', 'asd.5171', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/331337download (2).jpg'),
(268, 'Muhammad Mahad', 'IT-20-042@salu.edu.pk', 'asd.5172', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/524048download (2).jpg'),
(269, 'Muhammad Muzamil', 'IT-20-043@salu.edu.pk', 'asd.5173', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/960079download (2).jpg'),
(270, 'Muhammad Shoaib', 'IT-20-044@salu.edu.pk', 'asd.5174', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/758774download (2).jpg'),
(271, 'Muhammad Umar', 'IT-20-045@salu.edu.pk', 'asd.5175', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/768461download (2).jpg'),
(272, 'Muhammad Usama', 'IT-20-046@salu.edu.pk', 'asd.5176', 'Information Technology', '3', 33, 'Fifth', '../images/uploads/813699download (2).jpg'),
(273, 'Mulazim Ali', 'IT-20-047@salu.edu.pk', 'asd.5177', 'Information Technology', '3', 34, 'Fifth', '../images/uploads/472140download (2).jpg'),
(274, 'Mushahid Ali', 'IT-20-048@salu.edu.pk', 'asd.5178', 'Information Technology', '3', 34, 'Fifth', '../images/uploads/523266download (2).jpg'),
(275, 'Nabeel Ahmed', 'IT-20-049@salu.edu.pk', 'asd.5179', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/741197download (2).jpg'),
(276, 'Naeem Roshan', 'IT-20-050@salu.edu.pk', 'asd.5180', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/823654download (2).jpg'),
(277, 'Naina Shaheen', 'IT-20-051@salu.edu.pk', 'asd.5181', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/730895images.jpg'),
(278, 'Naveed Ahmed', 'IT-20-052@salu.edu.pk', 'asd.5182', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/707841download (2).jpg'),
(279, 'Rahul Kumar', 'IT-20-053@salu.edu.pk', 'asd.5183', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/267267download (2).jpg'),
(280, 'Rizwan Ramzan', 'IT-20-054@salu.edu.pk', 'asd.5184', 'Information Technology', '3', 33, 'Fifth', '../images/uploads/273591download (2).jpg'),
(281, 'Sada Hussain', 'IT-20-055@salu.edu.pk', 'asd.5185', 'Information Technology', '3', 34, 'Fifth', '../images/uploads/589212download (2).jpg'),
(282, 'Saifullah', 'IT-20-056@salu.edu.pk', 'asd.5186', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/875281download (2).jpg'),
(283, 'Sajad Ali', 'IT-20-057@salu.edu.pk', 'asd.5187', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/142682download (2).jpg'),
(284, 'Sajad Hussain', 'IT-20-058@salu.edu.pk', 'asd.5188', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/335323download (2).jpg'),
(285, 'Sakhawat Hussain', 'IT-20-059@salu.edu.pk', 'asd.5189', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/238263download (2).jpg'),
(286, 'Saqib Ali', 'IT-20-060@salu.edu.pk', 'asd.5190', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/15400download (2).jpg'),
(287, 'Saqlain Saleem', 'IT-20-061@salu.edu.pk', 'asd.5191', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/196248download (2).jpg'),
(288, 'Sarfaraz Ali', 'IT-20-062@salu.edu.pk', 'asd.5192', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/39831download (2).jpg'),
(289, 'Shakir Hussain', 'IT-20-063@salu.edu.pk', 'asd.5193', 'Information Technology', '3', 33, 'Fifth', '../images/uploads/772634download (2).jpg'),
(290, 'Shamshad Ali', 'IT-20-064@salu.edu.pk', 'asd.5194', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/1960download (2).jpg'),
(291, 'Sohail Abbas', 'IT-20-065@salu.edu.pk', 'asd.5195', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/414660download (2).jpg'),
(292, 'Tanveer Ahmed', 'IT-20-066@salu.edu.pk', 'asd.5196', 'Information Technology', '3', 34, 'Fifth', '../images/uploads/415994download (2).jpg'),
(293, 'Touseef Ahmed', 'IT-20-067@salu.edu.pk', 'asd.5197', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/98719download (2).jpg'),
(294, 'Ume Farwa', 'IT-20-068@salu.edu.pk', 'asd.5198', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/259478images.jpg'),
(295, 'Usama Mehmood', 'IT-20-069@salu.edu.pk', 'asd.5199', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/968573download (2).jpg'),
(296, 'Waseem Abbas', 'IT-20-070@salu.edu.pk', 'asd.5200', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/651137download (2).jpg'),
(297, 'Zain Ul Abdeen', 'IT-20-071@salu.edu.pk', 'asd.5201', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/314241download (2).jpg'),
(298, 'Zameer Ahmed', 'IT-20-072@salu.edu.pk', 'asd.5202', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/962702download (2).jpg'),
(299, 'Dinesh Kumar', 'IT-20-073@salu.edu.pk', 'asd.10122', 'Information Technology', '2', 31, 'Fifth', '../images/uploads/193150download (2).jpg'),
(300, 'Abdul Basit', 'IT-20-074@salu.edu.pk', 'asd.10059', 'Information Technology', '2', 32, 'Fifth', '../images/uploads/706936download (2).jpg'),
(301, 'Dua', 'IT-20-075@salu.edu.pk', 'asd.10066', 'Information Technology', '1', 29, 'Fifth', '../images/uploads/818809images.jpg'),
(302, 'Muskan', 'muskan20@gmail.com', 'muskan123', 'Information Technology', '1', 29, 'Third', '../images/uploads/273446images.jpg'),
(303, 'Mudasir Shaikh', 'shaikhmudasir7862@gmail.com', '0786', 'Information Technology', '1', 29, 'First', '../images/uploads/516491download (2).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `student_registration`
--

CREATE TABLE `student_registration` (
  `student_Id` int(11) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `education` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_registration`
--

INSERT INTO `student_registration` (`student_Id`, `userName`, `education`, `image`, `email`, `password`) VALUES
(1, 'Soha Shah', 'Computer Science', '../../learningManagementSystem/images/uploads/214382_dsc0765.jpg', 'ssrsohashah.com@gmail.com', 'soha123'),
(2, 'Sheeba Shah', 'Information Technology', '../../learningManagementSystem/images/uploads/383310_dsc0765.jpg', 'shahsheeba17@gmail.com', 'SHEEBA123'),
(3, 'Bushra Shah', 'Master in computer Science', '../../learningManagementSystem/images/uploads/651061_dsc0765.jpg', 'bushrashah12@gmail.com', 'bushra123'),
(4, 'Bushra Shah', 'Computer Science', '../../learningManagementSystem/images/uploads/355758_dsc0765.jpg', 'bushrashah23@gmail.com', 'bushra123'),
(5, 'Pir Muhammad Shah', 'Computer Science', '../../learningManagementSystem/images/uploads/163912download (2).jpg', 'pirmuhammadshah.com@gmail.com', '12pir123'),
(6, 'Abdul Ahad', 'Information Technology', '../../learningManagementSystem/images/uploads/887447png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-001@salu.edu.pk', 'asd.5062'),
(7, 'Abdul Hayee', 'Information Technology', '../../learningManagementSystem/images/uploads/535483png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-002@salu.edu.pk', 'asd.5063'),
(8, 'Abdul Khalique', 'Information Technology', '../../learningManagementSystem/images/uploads/190744png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-003@salu.edu.pk', 'asd.5064'),
(9, 'Abdul Malik', 'Information Technology', '../../learningManagementSystem/images/uploads/348083png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-004@salu.edu.pk', 'asd.5065'),
(10, 'Abdul Rafiu', 'Information Technology', '../../learningManagementSystem/images/uploads/435238png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-005@salu.edu.pk', 'asd.5066'),
(11, 'Abdul Rahman', 'Information Technology', '../../learningManagementSystem/images/uploads/284747png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-006@salu.edu.pk', 'asd.5067'),
(12, 'Abdul Samad', 'Information Technology', '../../learningManagementSystem/images/uploads/450494png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-007@salu.edu.pk', 'asd.5068'),
(13, 'Abdul Sami', 'Information Technology', '../../learningManagementSystem/images/uploads/526998png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-008@salu.edu.pk', 'asd.5069'),
(14, 'Abid Raza', 'Information Technology', '../../learningManagementSystem/images/uploads/183673png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-009@salu.edu.pk', 'asd.5070'),
(15, 'Abuzar Mehdi', 'Information Technology', '../../learningManagementSystem/images/uploads/915454png-transparent-computer-icons-avatar-boy-boys-child-face-heroes.png', 'IT-19-010@salu.edu.pk', 'asd.5071'),
(16, 'Adnan Ali', 'Information Technology', '../../learningManagementSystem/images/uploads/138698download (2).jpg', 'IT-19-011@salu.edu.pk', 'asd.5072'),
(17, 'Afifa', 'Information Technology', '../../learningManagementSystem/images/uploads/646123images.jpg', 'IT-19-012@salu.edu.pk', 'asd.5073'),
(18, 'Aftab', 'Information Technology', '../../learningManagementSystem/images/uploads/39979download (2).jpg', 'IT-19-013@salu.edu.pk', 'asd.5074'),
(19, 'Akhtar Ali', 'Information Technology', '../../learningManagementSystem/images/uploads/322166download (2).jpg', 'IT-19-014@salu.edu.pk', 'asd.5075'),
(20, 'Ali Gul', 'Information Technology', '../../learningManagementSystem/images/uploads/372705download (2).jpg', 'IT-19-015@salu.edu.pk', 'asd.5076'),
(21, 'Ali Murad', 'Information Technology', '../../learningManagementSystem/images/uploads/974384download (2).jpg', 'IT-19-016@salu.edu.pk', 'asd.5077'),
(22, 'Ameer Haider', 'Information Technology', '../../learningManagementSystem/images/uploads/121685download (2).jpg', 'IT-19-017@salu.edu.pk', 'asd.5078'),
(23, 'Ameer Ul Azeem', 'Information Technology', '../../learningManagementSystem/images/uploads/540958download (2).jpg', 'IT-19-018@salu.edu.pk', 'asd.5079'),
(24, 'Ansar Ali', 'Information Technology', '../../learningManagementSystem/images/uploads/175357download (2).jpg', 'IT-19-019@salu.edu.pk', 'asd.5080'),
(25, 'Aqib Hussain', 'Information Technology', '../../learningManagementSystem/images/uploads/977797download (2).jpg', 'IT-19-020@salu.edu.pk', 'asd.5081'),
(26, 'Arham Ali Agha', 'Information Technology', '../../learningManagementSystem/images/uploads/94412download (2).jpg', 'IT-19-021@salu.edu.pk', 'asd.5082'),
(27, 'Bushra Shah', 'Master in Information Technology', '../../learningManagementSystem/images/uploads/294347images.jpg', 'bushrarashdi234@gmail.com', 'bushra1212'),
(28, 'Muskan', 'Information Technology', '../../learningManagementSystem/images/uploads/622341images.jpg', 'muskan20@gmail.com', 'muskan123'),
(29, 'Mudasir Shaikh', 'Information Technology', '../../learningManagementSystem/images/uploads/631792download (2).jpg', 'shaikhmudasir7862@gmail.com', 'shaikh0786');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `category` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `Education` varchar(255) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `pdf_file_cv` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `UserName`, `Email`, `Password`, `category`, `courseId`, `Education`, `Image`, `pdf_file_cv`, `description`) VALUES
(39, 'Dr. Abdullah Maitlooooo', 'abdullah.maitlo@salu.edu.pk', 'abdullah20@', 1, 29, 'Computer Science', '../images/uploads/171606sir.jpg', '../files/861831resume.pdf', ''),
(41, 'Dr. Javed Ahmed Mahar', 'mahar.javed@salu.edu.pk', 'javedmahar@20', 1, 30, 'Computer Science', '../images/uploads/260997sirjavedmahar.jpg', '../files/961373resume.pdf', 'Professor Department of Computer Science'),
(42, 'Dr. Hidayatullah Shaikh', 'hiddayat@salu.edu.pk', 'shaikh20@', 2, 31, 'Computer Science', '../images/uploads/654772sirhiddayat.jpg', '../files/431686resume.pdf', 'Professor Department of Computer Science'),
(43, 'Dr. Mumtaz Hussain Mahar', 'mumtaz@salu.edu.pk', 'mumtaz20@', 2, 32, 'Computer Science', '../images/uploads/764659sirdean.jpg', '../files/858494resume.pdf', 'Professor Department of Computer Science'),
(44, 'Dr. Rafaquat Hussain Arain', 'rafaqat.arain@salu.edu.pk', 'rafaqat20@', 2, 32, 'Computer Science', '../images/uploads/932584b02c947c-73f1-434c-b00e-b2ddf70ebab3.jpg', '../files/434235resume.pdf', 'Associate Professor Department of Computer Science'),
(45, 'Mr. Asadullah Kehar', 'asad.kehar@salu.edu.pk', 'asad20@kahar', 3, 33, 'Computer Science', '../images/uploads/258864d4dd5460-1384-4b86-b8d0-e772d144025f.jpg', '../files/59825resume.pdf', 'Assistant Professor Department of Computer Science'),
(46, ' Dr. Riaz Ahmed Shaikh', 'riaz.shaikh@salu.edu.pk', 'riazshaikh@20', 3, 34, 'Computer Science', '../images/uploads/4498037b67c6dc-1f81-4d1e-bd1d-a2620df1e454.jpg', '../files/494690resume.pdf', 'Associate Professor Department of Computer Science');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Id` int(11) NOT NULL,
  `UserType` varchar(255) NOT NULL,
  `UserId` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Id`, `UserType`, `UserId`, `Email`, `Password`) VALUES
(15, '2', 39, 'abdullah.maitlo@salu.edu.pk', 'abdullah20@'),
(16, '2', 40, 'mahar.javed@salu.edu.pk', 'javedmahar20@'),
(17, '2', 41, 'mahar.javed@salu.edu.pk', 'javedmahar@20'),
(18, '2', 42, 'hiddayat@salu.edu.pk', 'shaikh20@'),
(19, '2', 43, 'mumtaz@salu.edu.pk', 'mumtaz20@'),
(20, '2', 44, 'rafaqat.arain@salu.edu.pk', 'rafaqat20@'),
(21, '2', 45, 'asad.kehar@salu.edu.pk', 'asad20@kahar'),
(22, '2', 46, 'riaz.shaikh@salu.edu.pk', 'riazshaikh@20'),
(23, '2', 47, 'shahid.danwar@salu.edu.pk', 'shahid20@'),
(24, '1', 6, 'CS-19-001@salu.edu.pk', 'asd.2691'),
(25, '1', 7, 'CS-19-002@salu.edu.pk', 'asd.2692'),
(26, '1', 8, 'CS-19-003@salu.edu.pk', 'asd.2693'),
(27, '1', 9, 'CS-19-004@salu.edu.pk', 'asd.2694'),
(28, '1', 10, 'CS-19-005@salu.edu.pk', 'asd.2695'),
(29, '1', 11, 'CS-19-006@salu.edu.pk', 'asd.2696'),
(30, '1', 12, 'CS-19-007@salu.edu.pk', 'asd.2697'),
(31, '1', 13, 'CS-19-008@salu.edu.pk', 'asd.2698'),
(32, '1', 14, 'CS-19-009@salu.edu.pk', 'asd.2699'),
(33, '1', 15, 'CS-19-010@salu.edu.pk', 'asd.2700'),
(34, '1', 16, 'CS-19-011@salu.edu.pk', 'asd.2701'),
(35, '1', 17, 'CS-19-012@salu.edu.pk', 'asd.2702'),
(36, '1', 18, 'CS-19-013@salu.edu.pk', 'asd.2703'),
(37, '1', 19, 'CS-19-014@salu.edu.pk', 'asd.2704'),
(38, '1', 20, 'CS-19-015@salu.edu.pk', 'asd.2705'),
(39, '1', 21, 'CS-19-016@salu.edu.pk', 'asd.2706'),
(40, '1', 22, 'CS-19-017@salu.edu.pk', 'asd.2707'),
(41, '1', 23, 'CS-19-018@salu.edu.pk', 'asd.2708'),
(42, '1', 24, 'CS-19-019@salu.edu.pk', 'asd.2709'),
(43, '1', 25, 'CS-19-020@salu.edu.pk', 'asd.2710'),
(44, '1', 26, 'CS-19-021@salu.edu.pk', 'asd.2711'),
(45, '1', 27, 'CS-19-022@salu.edu.pk', 'asd.2712'),
(46, '1', 28, 'CS-19-023@salu.edu.pk', 'asd.2713'),
(47, '1', 29, 'CS-19-024@salu.edu.pk', 'asd.2714'),
(48, '1', 30, 'CS-19-025@salu.edu.pk', 'asd.2715'),
(49, '1', 31, 'CS-19-026@salu.edu.pk', 'asd.2716'),
(50, '1', 32, 'CS-19-027@salu.edu.pk', 'asd.2717'),
(51, '1', 33, 'CS-19-028@salu.edu.pk', 'asd.2718'),
(52, '1', 34, 'CS-19-029@salu.edu.pk', 'asd.2719'),
(53, '1', 35, 'CS-19-030@salu.edu.pk', 'asd.2720'),
(54, '1', 36, 'CS-19-031@salu.edu.pk', 'asd.2721'),
(55, '1', 37, 'CS-19-032@salu.edu.pk', 'asd.2722'),
(56, '1', 38, 'CS-19-033@salu.edu.pk', 'asd.2723'),
(57, '1', 39, 'CS-19-034@salu.edu.pk', 'asd.2724'),
(58, '1', 40, 'CS-19-035@salu.edu.pk', 'asd.2725'),
(59, '1', 41, 'CS-19-036@salu.edu.pk', 'asd.2726'),
(60, '1', 42, 'CS-19-037@salu.edu.pk', 'asd.2727'),
(61, '1', 43, 'CS-19-038@salu.edu.pk', 'asd.2728'),
(62, '1', 44, 'CS-19-039@salu.edu.pk', 'asd.2729'),
(63, '1', 45, 'CS-19-040@salu.edu.pk', 'asd.2730'),
(64, '1', 46, 'CS-19-041@salu.edu.pk', 'asd.2731'),
(65, '1', 47, 'CS-19-042@salu.edu.pk', 'asd.2732'),
(66, '1', 48, 'CS-19-043@salu.edu.pk', 'asd.2733'),
(67, '1', 49, 'CS-19-044@salu.edu.pk', 'asd.2734'),
(68, '1', 50, 'CS-19-045@salu.edu.pk', 'asd.2735'),
(69, '1', 51, 'CS-19-046@salu.edu.pk', 'asd.2736'),
(70, '1', 52, 'CS-19-047@salu.edu.pk', 'asd.2737'),
(71, '1', 53, 'CS-19-048@salu.edu.pk', 'asd.2738'),
(72, '1', 54, 'CS-19-049@salu.edu.pk', 'asd.2739'),
(73, '1', 55, 'CS-19-050@salu.edu.pk', 'asd.2740'),
(74, '1', 56, 'CS-19-051@salu.edu.pk', 'asd.2741'),
(75, '1', 57, 'CS-19-052@salu.edu.pk', 'asd.2742'),
(76, '1', 58, 'CS-19-053@salu.edu.pk', 'asd.2743'),
(77, '1', 59, 'CS-19-054@salu.edu.pk', 'asd.2744'),
(78, '1', 60, 'CS-19-055@salu.edu.pk', 'asd.2745'),
(79, '1', 61, 'CS-19-056@salu.edu.pk', 'asd.2746'),
(80, '1', 62, 'CS-19-057@salu.edu.pk', 'asd.2747'),
(81, '1', 63, 'CS-19-058@salu.edu.pk', 'asd.2748'),
(82, '1', 64, 'CS-19-059@salu.edu.pk', 'asd.2749'),
(83, '1', 65, 'CS-19-060@salu.edu.pk', 'asd.2750'),
(84, '1', 66, 'CS-19-061@salu.edu.pk', 'asd.2751'),
(85, '1', 67, 'CS-19-062@salu.edu.pk', 'asd.2752'),
(86, '1', 68, 'CS-19-063@salu.edu.pk', 'asd.2753'),
(87, '1', 69, 'CS-19-064@salu.edu.pk', 'asd.2754'),
(88, '1', 70, 'CS-19-065@salu.edu.pk', 'asd.10062'),
(90, '1', 71, 'pirmuhammadshah.com@gmail.com', '12pir12'),
(91, '1', 72, 'CS-20-001@salu.edu.pk', 'asd.2755'),
(92, '1', 73, 'CS-20-002@salu.edu.pk', 'asd.2756'),
(93, '1', 74, 'CS-20-003@salu.edu.pk', 'asd.2757'),
(94, '1', 75, 'CS-20-004@salu.edu.pk', 'asd.2758'),
(95, '1', 76, 'CS-20-005@salu.edu.pk', 'asd.2759'),
(96, '1', 77, 'CS-20-006@salu.edu.pk', 'asd.2760'),
(97, '1', 78, 'CS-20-007@salu.edu.pk', 'asd.2761'),
(98, '1', 79, 'CS-20-008@salu.edu.pk', 'asd.2762'),
(99, '1', 80, 'CS-20-009@salu.edu.pk', 'asd.2763'),
(100, '1', 81, 'CS-20-010@salu.edu.pk', 'asd.2764'),
(101, '1', 82, 'CS-20-011@salu.edu.pk', 'asd.2765'),
(102, '1', 83, 'CS-20-012@salu.edu.pk', 'asd.2766'),
(103, '1', 84, 'CS-20-013@salu.edu.pk', 'asd.2767'),
(104, '1', 85, 'CS-20-014@salu.edu.pk', 'asd.2768'),
(105, '1', 86, 'CS-20-015@salu.edu.pk', 'asd.2769'),
(106, '1', 87, 'CS-20-016@salu.edu.pk', 'asd.2770'),
(107, '1', 88, 'CS-20-017@salu.edu.pk', 'asd.2771'),
(108, '1', 89, 'CS-20-018@salu.edu.pk', 'asd.2772'),
(109, '1', 90, 'CS-20-019@salu.edu.pk', 'asd.2773'),
(110, '1', 91, 'CS-20-020@salu.edu.pk', 'asd.2774'),
(111, '1', 92, 'CS-20-021@salu.edu.pk', 'asd.2775'),
(112, '1', 93, 'CS-20-022@salu.edu.pk', 'asd.2776'),
(113, '1', 94, 'CS-20-023@salu.edu.pk', 'asd.2777'),
(114, '1', 95, 'CS-20-024@salu.edu.pk', 'asd.2778'),
(115, '1', 96, 'CS-20-025@salu.edu.pk', 'asd.2779'),
(116, '1', 97, 'CS-20-026@salu.edu.pk', 'asd.2780'),
(117, '1', 98, 'CS-20-027@salu.edu.pk', 'asd.2781'),
(118, '1', 99, 'CS-20-028@salu.edu.pk', 'asd.2782'),
(119, '1', 100, 'CS-20-029@salu.edu.pk', 'asd.2783'),
(120, '1', 101, 'CS-20-030@salu.edu.pk', 'asd.2784'),
(121, '1', 102, 'CS-20-031@salu.edu.pk', 'asd.2785'),
(122, '1', 103, 'CS-20-032@salu.edu.pk', 'asd.2786'),
(123, '1', 104, 'CS-20-033@salu.edu.pk', 'asd.2787'),
(124, '1', 105, 'CS-20-034@salu.edu.pk', 'asd.2788'),
(125, '1', 106, 'CS-20-035@salu.edu.pk', 'asd.2789'),
(126, '1', 107, 'CS-20-036@salu.edu.pk', 'asd.2790'),
(127, '1', 108, 'CS-20-037@salu.edu.pk', 'asd.2791'),
(128, '1', 109, 'CS-20-038@salu.edu.pk', 'asd.2792'),
(129, '1', 110, 'CS-20-039@salu.edu.pk', 'asd.2793'),
(130, '1', 111, 'CS-20-040@salu.edu.pk', 'asd.2794'),
(131, '1', 112, 'CS-20-041@salu.edu.pk', 'asd.2795'),
(132, '1', 113, 'CS-20-042@salu.edu.pk', 'asd.2796'),
(133, '1', 114, 'CS-20-043@salu.edu.pk', 'asd.2797'),
(134, '1', 115, 'CS-20-044@salu.edu.pk', 'asd.2798'),
(135, '1', 116, 'CS-20-045@salu.edu.pk', 'asd.2799'),
(136, '1', 117, 'CS-20-046@salu.edu.pk', 'asd.2800'),
(137, '1', 118, 'CS-20-047@salu.edu.pk', 'asd.2801'),
(138, '1', 119, 'CS-20-048@salu.edu.pk', 'asd.2802'),
(139, '1', 120, 'CS-20-049@salu.edu.pk', 'asd.2803'),
(140, '1', 121, 'CS-20-050@salu.edu.pk', 'asd.2804'),
(141, '1', 122, 'CS-20-051@salu.edu.pk', 'asd.2805'),
(142, '1', 123, 'CS-20-052@salu.edu.pk', 'asd.2806'),
(143, '1', 124, 'CS-20-053@salu.edu.pk', 'asd.2807'),
(144, '1', 125, 'CS-20-054@salu.edu.pk', 'asd.2808'),
(145, '1', 126, 'CS-20-055@salu.edu.pk', 'asd.2809'),
(146, '1', 127, 'CS-20-056@salu.edu.pk', 'asd.2810'),
(147, '1', 128, 'CS-20-057@salu.edu.pk', 'asd.2811'),
(148, '1', 129, 'CS-20-058@salu.edu.pk', 'asd.2812'),
(149, '1', 130, 'CS-20-059@salu.edu.pk', 'asd.2813'),
(150, '1', 131, 'CS-20-060@salu.edu.pk', 'asd.2814'),
(151, '1', 132, 'CS-20-061@salu.edu.pk', 'asd.2815'),
(152, '1', 133, 'CS-20-062@salu.edu.pk', 'asd.2816'),
(153, '1', 134, 'CS-20-063@salu.edu.pk', 'asd.2817'),
(154, '1', 135, 'CS-20-064@salu.edu.pk', 'asd.2818'),
(155, '1', 136, 'CS-20-065@salu.edu.pk', 'asd.2819'),
(156, '1', 137, 'CS-20-066@salu.edu.pk', 'asd.2820'),
(157, '1', 138, 'CS-20-067@salu.edu.pk', 'asd.2821'),
(158, '1', 139, 'CS-20-068@salu.edu.pk', 'asd.2822'),
(159, '1', 140, 'CS-20-069@salu.edu.pk', 'asd.2823'),
(160, '1', 141, 'CS-20-070@salu.edu.pk', 'asd.2824'),
(161, '1', 142, 'CS-20-071@salu.edu.pk', 'asd.2825'),
(162, '1', 143, 'CS-20-072@salu.edu.pk', 'asd.2826'),
(163, '1', 144, 'CS-20-073@salu.edu.pk', 'asd.2827'),
(164, '1', 145, 'CS-20-074@salu.edu.pk', 'asd.2828'),
(165, '1', 146, 'CS-20-075@salu.edu.pk', 'asd.2829'),
(166, '1', 147, 'CS-20-076@salu.edu.pk', 'asd.2830'),
(167, '1', 148, 'CS-20-077@salu.edu.pk', 'asd.9560'),
(168, '1', 149, 'CS-20-078@salu.edu.pk', 'asd.9561'),
(169, '1', 150, 'CS-20-079@salu.edu.pk', 'asd.9562'),
(170, '1', 151, 'CS-20-080@salu.edu.pk', 'asd.9797'),
(171, '1', 152, 'CS-20-081@salu.edu.pk', 'asd.9798'),
(172, '1', 153, 'CS-20-082@salu.edu.pk', 'asd.10057'),
(173, '1', 154, 'CS-20-083@salu.edu.pk', 'asd.10064'),
(174, '1', 155, 'CS-20-084@salu.edu.pk', 'asd.10136'),
(175, '1', 6, 'IT-19-001@salu.edu.pk', 'asd.5062'),
(176, '1', 7, 'IT-19-002@salu.edu.pk', 'asd.5063'),
(177, '1', 8, 'IT-19-003@salu.edu.pk', 'asd.5064'),
(178, '1', 9, 'IT-19-004@salu.edu.pk', 'asd.5065'),
(179, '1', 10, 'IT-19-005@salu.edu.pk', 'asd.5066'),
(180, '1', 11, 'IT-19-006@salu.edu.pk', 'asd.5067'),
(181, '1', 12, 'IT-19-007@salu.edu.pk', 'asd.5068'),
(182, '1', 13, 'IT-19-008@salu.edu.pk', 'asd.5069'),
(183, '1', 14, 'IT-19-009@salu.edu.pk', 'asd.5070'),
(184, '1', 15, 'IT-19-010@salu.edu.pk', 'asd.5071'),
(185, '1', 16, 'IT-19-011@salu.edu.pk', 'asd.5072'),
(186, '1', 17, 'IT-19-012@salu.edu.pk', 'asd.5073'),
(187, '1', 18, 'IT-19-013@salu.edu.pk', 'asd.5074'),
(188, '1', 19, 'IT-19-014@salu.edu.pk', 'asd.5075'),
(189, '1', 20, 'IT-19-015@salu.edu.pk', 'asd.5076'),
(190, '1', 21, 'IT-19-016@salu.edu.pk', 'asd.5077'),
(191, '1', 22, 'IT-19-017@salu.edu.pk', 'asd.5078'),
(192, '1', 23, 'IT-19-018@salu.edu.pk', 'asd.5079'),
(193, '1', 24, 'IT-19-019@salu.edu.pk', 'asd.5080'),
(194, '1', 25, 'IT-19-020@salu.edu.pk', 'asd.5081'),
(195, '1', 26, 'IT-19-021@salu.edu.pk', 'asd.5082'),
(196, '1', 156, 'IT-19-001@salu.edu.pk', 'asd.5062'),
(197, '1', 157, 'IT-19-002@salu.edu.pk', 'asd.5063'),
(198, '1', 158, 'IT-19-003@salu.edu.pk', 'asd.5064'),
(199, '1', 159, 'IT-19-004@salu.edu.pk', 'asd.5065'),
(200, '1', 160, 'IT-19-005@salu.edu.pk', 'asd.5066'),
(201, '1', 161, 'IT-19-006@salu.edu.pk', 'asd.5067'),
(202, '1', 162, 'IT-19-007@salu.edu.pk', 'asd.5068'),
(203, '1', 163, 'IT-19-008@salu.edu.pk', 'asd.5069'),
(204, '1', 164, 'IT-19-009@salu.edu.pk', 'asd.5070'),
(205, '1', 165, 'IT-19-010@salu.edu.pk', 'asd.5071'),
(206, '1', 166, 'IT-19-011@salu.edu.pk', 'asd.5072'),
(207, '1', 167, 'IT-19-012@salu.edu.pk', 'asd.5073'),
(208, '1', 168, 'IT-19-013@salu.edu.pk', 'asd.5074'),
(209, '1', 169, 'IT-19-014@salu.edu.pk', 'asd.5075'),
(210, '1', 170, 'IT-19-015@salu.edu.pk', 'asd.5076'),
(211, '1', 171, 'IT-19-016@salu.edu.pk', 'asd.5077'),
(212, '1', 172, 'IT-19-017@salu.edu.pk', 'asd.5078'),
(213, '1', 173, 'IT-19-018@salu.edu.pk', 'asd.5079'),
(214, '1', 174, 'IT-19-019@salu.edu.pk', 'asd.5080'),
(215, '1', 175, 'IT-19-020@salu.edu.pk', 'asd.5081'),
(216, '1', 176, 'IT-19-021@salu.edu.pk', 'asd.5082'),
(217, '1', 177, 'IT-19-022@salu.edu.pk', 'asd.5083'),
(218, '1', 178, 'IT-19-023@salu.edu.pk', 'asd.5084'),
(219, '1', 179, 'IT-19-024@salu.edu.pk', 'asd.5085'),
(220, '1', 180, 'IT-19-025@salu.edu.pk', 'asd.5086'),
(221, '1', 181, 'IT-19-026@salu.edu.pk', 'asd.5087'),
(222, '1', 182, 'IT-19-027@salu.edu.pk', 'asd.5088'),
(223, '1', 183, 'IT-19-028@salu.edu.pk', 'asd.5089'),
(224, '1', 184, 'IT-19-029@salu.edu.pk', 'asd.5090'),
(225, '1', 185, 'IT-19-030@salu.edu.pk', 'asd.5091'),
(226, '1', 186, 'IT-19-031@salu.edu.pk', 'asd.5092'),
(227, '1', 187, 'IT-19-032@salu.edu.pk', 'asd.5093'),
(228, '1', 188, 'IT-19-033@salu.edu.pk', 'asd.5094'),
(229, '1', 189, 'IT-19-034@salu.edu.pk', 'asd.5095'),
(230, '1', 190, 'IT-19-035@salu.edu.pk', 'asd.5096'),
(231, '1', 191, 'IT-19-036@salu.edu.pk', 'asd.5097'),
(232, '1', 192, 'IT-19-037@salu.edu.pk', 'asd.5098'),
(233, '1', 193, 'IT-19-038@salu.edu.pk', 'asd.5099'),
(234, '1', 194, 'IT-19-039@salu.edu.pk', 'asd.5100'),
(235, '1', 195, 'IT-19-040@salu.edu.pk', 'asd.5101'),
(236, '1', 196, 'IT-19-041@salu.edu.pk', 'asd.5102'),
(237, '1', 197, 'IT-19-042@salu.edu.pk', 'asd.5103'),
(238, '1', 198, 'IT-19-043@salu.edu.pk', 'asd.5104'),
(239, '1', 199, 'IT-19-044@salu.edu.pk', 'asd.5105'),
(240, '1', 200, 'IT-19-045@salu.edu.pk', 'asd.5106'),
(241, '1', 201, 'IT-19-046@salu.edu.pk', 'asd.5107'),
(242, '1', 202, 'IT-19-047@salu.edu.pk', 'asd.5108'),
(243, '1', 203, 'IT-19-048@salu.edu.pk', 'asd.5109'),
(244, '1', 204, 'IT-19-049@salu.edu.pk', 'asd.5110'),
(245, '1', 205, 'IT-19-050@salu.edu.pk', 'asd.5111'),
(246, '1', 206, 'IT-19-051@salu.edu.pk', 'asd.5112'),
(247, '1', 207, 'IT-19-052@salu.edu.pk', 'asd.5113'),
(248, '1', 208, 'IT-19-053@salu.edu.pk', 'asd.5114'),
(249, '1', 209, 'IT-19-054@salu.edu.pk', 'asd.5115'),
(250, '1', 210, 'IT-19-055@salu.edu.pk', 'asd.5116'),
(251, '1', 211, 'IT-19-056@salu.edu.pk', 'asd.5117'),
(252, '1', 212, 'IT-19-057@salu.edu.pk', 'asd.5118'),
(253, '1', 213, 'IT-19-058@salu.edu.pk', 'asd.5119'),
(254, '1', 214, 'IT-19-059@salu.edu.pk', 'asd.5120'),
(255, '1', 215, 'IT-19-060@salu.edu.pk', 'asd.5121'),
(256, '1', 216, 'IT-19-061@salu.edu.pk', 'asd.5122'),
(257, '1', 217, 'IT-19-062@salu.edu.pk', 'asd.5123'),
(258, '1', 218, 'IT-19-063@salu.edu.pk', 'asd.5124'),
(259, '1', 219, 'IT-19-064@salu.edu.pk', 'asd.5125'),
(260, '1', 220, 'IT-19-065@salu.edu.pk', 'asd.5126'),
(261, '1', 221, 'IT-19-066@salu.edu.pk', 'asd.5127'),
(262, '1', 222, 'IT-19-067@salu.edu.pk', 'asd.5128'),
(263, '1', 223, 'IT-19-068@salu.edu.pk', 'asd.5129'),
(264, '1', 224, 'IT-19-069@salu.edu.pk', 'asd.5130'),
(265, '1', 225, 'IT-19-070@salu.edu.pk', 'asd.5131'),
(266, '1', 226, 'IT-19-071@salu.edu.pk', 'asd.5132'),
(267, '1', 227, 'IT-19-072@salu.edu.pk', 'asd.10063'),
(268, '1', 228, 'IT-19-073@salu.edu.pk', 'asd.10121'),
(269, '1', 229, 'IT-20-002@salu.edu.pk', 'asd.5133'),
(270, '1', 230, 'IT-20-003@salu.edu.pk', 'asd.5134'),
(271, '1', 231, 'IT-20-004@salu.edu.pk', 'asd.5135'),
(272, '1', 232, 'IT-20-005@salu.edu.pk', 'asd.5136'),
(273, '1', 233, 'IT-20-006@salu.edu.pk', 'asd.5137'),
(274, '1', 234, 'IT-20-007@salu.edu.pk', 'asd.5138'),
(275, '1', 235, 'IT-20-008@salu.edu.pk', 'asd.5139'),
(276, '1', 236, 'IT-20-009@salu.edu.pk', 'asd.5140'),
(277, '1', 237, 'IT-20-010@salu.edu.pk', 'asd.5141'),
(278, '1', 238, 'IT-20-011@salu.edu.pk', 'asd.5142'),
(279, '1', 239, 'IT-20-012@salu.edu.pk', 'asd.5143'),
(280, '1', 240, 'IT-20-013@salu.edu.pk', 'asd.5144'),
(281, '1', 241, 'IT-20-014@salu.edu.pk', 'asd.5145'),
(282, '1', 242, 'IT-20-016@salu.edu.pk', 'asd.5146'),
(283, '1', 243, 'IT-20-017@salu.edu.pk', 'asd.5147'),
(284, '1', 244, 'IT-20-018@salu.edu.pk', 'asd.5148'),
(285, '1', 245, 'IT-20-019@salu.edu.pk', 'asd.5149'),
(286, '1', 246, 'IT-20-020@salu.edu.pk', 'asd.5150'),
(287, '1', 247, 'IT-20-021@salu.edu.pk', 'asd.5151'),
(288, '1', 248, 'IT-20-022@salu.edu.pk', 'asd.5152'),
(289, '1', 249, 'IT-20-023@salu.edu.pk', 'asd.5153'),
(290, '1', 250, 'IT-20-024@salu.edu.pk', 'asd.5154'),
(291, '1', 251, 'IT-20-025@salu.edu.pk', 'asd.5155'),
(292, '1', 252, 'IT-20-026@salu.edu.pk', 'asd.5156'),
(293, '1', 253, 'IT-20-027@salu.edu.pk', 'asd.5157'),
(294, '1', 254, 'IT-20-028@salu.edu.pk', 'asd.5158'),
(295, '1', 255, 'IT-20-029@salu.edu.pk', 'asd.5159'),
(296, '1', 256, 'IT-20-030@salu.edu.pk', 'asd.5160'),
(297, '1', 257, 'IT-20-031@salu.edu.pk', 'asd.5161'),
(298, '1', 258, 'IT-20-032@salu.edu.pk', 'asd.5162'),
(299, '1', 259, 'IT-20-033@salu.edu.pk', 'asd.5163'),
(300, '1', 260, 'IT-20-034@salu.edu.pk', 'asd.5164'),
(301, '1', 261, 'IT-20-035@salu.edu.pk', 'asd.5165'),
(302, '1', 262, 'IT-20-036@salu.edu.pk', 'asd.5166'),
(303, '1', 263, 'IT-20-037@salu.edu.pk', 'asd.5167'),
(304, '1', 264, 'IT-20-038@salu.edu.pk', 'asd.5168'),
(305, '1', 265, 'IT-20-039@salu.edu.pk', 'asd.5169'),
(306, '1', 266, 'IT-20-040@salu.edu.pk', 'asd.5170'),
(307, '1', 267, 'IT-20-041@salu.edu.pk', 'asd.5171'),
(308, '1', 268, 'IT-20-042@salu.edu.pk', 'asd.5172'),
(309, '1', 269, 'IT-20-043@salu.edu.pk', 'asd.5173'),
(310, '1', 270, 'IT-20-044@salu.edu.pk', 'asd.5174'),
(311, '1', 271, 'IT-20-045@salu.edu.pk', 'asd.5175'),
(312, '1', 272, 'IT-20-046@salu.edu.pk', 'asd.5176'),
(313, '1', 273, 'IT-20-047@salu.edu.pk', 'asd.5177'),
(314, '1', 274, 'IT-20-048@salu.edu.pk', 'asd.5178'),
(315, '1', 275, 'IT-20-049@salu.edu.pk', 'asd.5179'),
(316, '1', 276, 'IT-20-050@salu.edu.pk', 'asd.5180'),
(317, '1', 277, 'IT-20-051@salu.edu.pk', 'asd.5181'),
(318, '1', 278, 'IT-20-052@salu.edu.pk', 'asd.5182'),
(319, '1', 279, 'IT-20-053@salu.edu.pk', 'asd.5183'),
(320, '1', 280, 'IT-20-054@salu.edu.pk', 'asd.5184'),
(321, '1', 281, 'IT-20-055@salu.edu.pk', 'asd.5185'),
(322, '1', 282, 'IT-20-056@salu.edu.pk', 'asd.5186'),
(323, '1', 283, 'IT-20-057@salu.edu.pk', 'asd.5187'),
(324, '1', 284, 'IT-20-058@salu.edu.pk', 'asd.5188'),
(325, '1', 285, 'IT-20-059@salu.edu.pk', 'asd.5189'),
(326, '1', 286, 'IT-20-060@salu.edu.pk', 'asd.5190'),
(327, '1', 287, 'IT-20-061@salu.edu.pk', 'asd.5191'),
(328, '1', 288, 'IT-20-062@salu.edu.pk', 'asd.5192'),
(329, '1', 289, 'IT-20-063@salu.edu.pk', 'asd.5193'),
(330, '1', 290, 'IT-20-064@salu.edu.pk', 'asd.5194'),
(331, '1', 291, 'IT-20-065@salu.edu.pk', 'asd.5195'),
(332, '1', 292, 'IT-20-066@salu.edu.pk', 'asd.5196'),
(333, '1', 293, 'IT-20-067@salu.edu.pk', 'asd.5197'),
(334, '1', 294, 'IT-20-068@salu.edu.pk', 'asd.5198'),
(335, '1', 295, 'IT-20-069@salu.edu.pk', 'asd.5199'),
(336, '1', 296, 'IT-20-070@salu.edu.pk', 'asd.5200'),
(337, '1', 297, 'IT-20-071@salu.edu.pk', 'asd.5201'),
(338, '1', 298, 'IT-20-072@salu.edu.pk', 'asd.5202'),
(339, '1', 299, 'IT-20-073@salu.edu.pk', 'asd.10122'),
(340, '1', 300, 'IT-20-074@salu.edu.pk', 'asd.10059'),
(341, '1', 301, 'IT-20-075@salu.edu.pk', 'asd.10066'),
(342, '1', 27, 'bushrarashdi234@gmail.com', 'bushra1212'),
(343, '1', 28, 'muskan20@gmail.com', 'muskan123'),
(344, '1', 302, 'muskan20@gmail.com', 'muskan123'),
(345, '1', 29, 'shaikhmudasir7862@gmail.com', '0786'),
(346, '1', 303, 'shaikhmudasir7862@gmail.com', '0786');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `userTypeId` int(11) NOT NULL,
  `UserType` varchar(255) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`userTypeId`, `UserType`, `Email`, `Password`) VALUES
(1, 'Student', '', ''),
(2, 'Teacher', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`courseId`);

--
-- Indexes for table `course_category`
--
ALTER TABLE `course_category`
  ADD PRIMARY KEY (`courseCategoryId`);

--
-- Indexes for table `course_uploaded_teacher`
--
ALTER TABLE `course_uploaded_teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pending_teacher`
--
ALTER TABLE `pending_teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`semesterId`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `student_registration`
--
ALTER TABLE `student_registration`
  ADD PRIMARY KEY (`student_Id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`userTypeId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `courseId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `course_category`
--
ALTER TABLE `course_category`
  MODIFY `courseCategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `course_uploaded_teacher`
--
ALTER TABLE `course_uploaded_teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pending_teacher`
--
ALTER TABLE `pending_teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `semesterId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=304;

--
-- AUTO_INCREMENT for table `student_registration`
--
ALTER TABLE `student_registration`
  MODIFY `student_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=347;

--
-- AUTO_INCREMENT for table `user_type`
--
ALTER TABLE `user_type`
  MODIFY `userTypeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
