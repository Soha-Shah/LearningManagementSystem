<?php
include 'database.php';

if(isset($_POST['action'])){

 $studentEmail = $_POST['studentEmail'];
 $sql ="select * from student where email = '$studentEmail' ";
 $result = $conn->query($sql);
 $students=[];
 if($result->num_rows>0){
   while($row = $result->fetch_assoc()) {
     $students []= $row;
   }
   echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found","Data"=>$students));
 }
 else{
  echo json_encode(array("StatusCode"=>"200", "Message"=>"No Data Found"));
 }

}



 ?>
