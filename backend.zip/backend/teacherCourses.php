<?php
include 'database.php';

if(isset($_POST['action']) && $_POST['action']=="getCourses"){

 $teacherEmail = $_POST['teacherEmail'];
 $query = "SELECT * FROM courses INNER JOIN teacher ON courses.courseId = teacher.courseId


            WHERE teacher.Email = '".$teacherEmail."'";
 //$sql ="select * from admin where Email = '$adminEmail' ";
 $result = $conn->query($query);
 $teachers=[];
 if($result->num_rows>0){
   while($row = $result->fetch_assoc()) {
     $teachers []= $row;
   }
   echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found","Data"=>$teachers));
 }
 else{
  echo json_encode(array("StatusCode"=>"200", "Message"=>"No Data Found"));
 }

}



else if(isset($_POST['action']) && $_POST['action']=="getCourseCategories"){

 $teacherEmail = $_POST['teacherEmail'];
 $query = "SELECT * FROM course_category INNER JOIN teacher ON course_category.courseCategoryId = teacher.category


            WHERE teacher.Email = '".$teacherEmail."'";
 //$sql ="select * from admin where Email = '$adminEmail' ";
 $result = $conn->query($query);
 $teachers=[];
 if($result->num_rows>0){
   while($row = $result->fetch_assoc()) {
     $teachers []= $row;
   }
   echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found","Data"=>$teachers));
 }
 else{
  echo json_encode(array("StatusCode"=>"200", "Message"=>"No Data Found"));
 }

}



 ?>
