<?php
include 'database.php';

if(isset($_POST['action']) && $_POST['action']=="getAssignment"){
  $teacherEmail = $_POST['teacherEmail'];
  //$getCourses = "SELECT * from assignment as A inner join teacher as T On T.courseId = A.courseId where T.Email = '".$teacherEmail."'";
  //$getStudents = "SELECT * FROM assignment";
  $query = "SELECT * FROM teacher INNER JOIN courses ON courses.courseId = teacher.courseId
             INNER JOIN assignment
             ON  assignment.courseId = teacher.courseId
             WHERE teacher.Email = '".$teacherEmail."'";



  $result = $conn->query($query);
  $students= [];
  if($result->num_rows>0){
    while($row = $result->fetch_assoc()) {
      $students []= $row;
    }
    echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$students));
  }
  else{
    echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
  }
}

else if(isset($_POST['action']) && $_POST['action']=="DeleteAssignmentData"){
  $assignmentId = $_POST['assignmentId'];
  $sql ="DELETE  FROM assignment where assignment_id = '$assignmentId'";
  $result = $conn->query($sql);

  if ($result) {
    echo json_encode(array("StatusCode"=>"200", "Message"=>"Assignment Deleted Successfully"));
  }

  else{
    echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
  }
}

?>
