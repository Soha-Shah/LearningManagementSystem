<?php
include 'database.php';
if(isset($_POST['action']) && $_POST['action']=="webStudents"){
  $teacherEmail = $_POST['teacherEmail'];
  $getStudents = "SELECT * from student as S inner join teacher as T On T.courseId = S.courseId where T.Email = '".$teacherEmail."'";
  // $query = "SELECT * FROM student INNER JOIN student ON student.courseId = teacher.courseId
  //            INNER JOIN teacher
  //            ON teacher.courseId = student.courseId
  //            WHERE teacher.Email = '".$teacherEmail."'";
  //$query = "SELECT * from book as B inner join student as S On S.courseId = B.courseId where S.email = '".$studentEmail."'";
  $query = "SELECT * FROM teacher INNER JOIN courses ON courses.courseId = teacher.courseId
             INNER JOIN student
             ON  student.courseId = teacher.courseId
             WHERE teacher.Email = '".$teacherEmail."'";



  $result = $conn->query($query);
  $students= [];
  if($result->num_rows>0){
    while($row = $result->fetch_assoc()) {
      $students []= $row;
    }
    echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$students));
  }
  else{
    echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
  }
}

 ?>
