<?php
include 'database.php';

$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt'); // valid extensions
$path = '../images/uploads/'; // upload directory
$pathpdf = '../files/';

if($_FILES['image'])
{
  $img = $_FILES['image']['name'];
  $tmp = $_FILES['image']['tmp_name'];

  $pdf = $_FILES['pdf']['name'];
  $pdftmp = $_FILES['pdf']['tmp_name'];

  // get uploaded file's extension
  $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
  $extpdf = strtolower(pathinfo($pdf, PATHINFO_EXTENSION));

  // can upload same image using rand function
  $final_image = rand(1000,1000000).$img;
  $final_pdf = rand(1000,1000000).$pdf;

  // check's valid format
  if(in_array($ext, $valid_extensions) && in_array($extpdf, $valid_extensions))
  {
    $path = $path.strtolower($final_image);
    $pathpdf = $pathpdf.strtolower($final_pdf);
    $path = str_replace(' ', '', $path);
    $pathpdf = str_replace(' ', '', $pathpdf);

    if(move_uploaded_file($tmp,$path) && move_uploaded_file($pdftmp,$pathpdf))
    {
      $UserName = $_POST['UserName'];
      $email = $_POST['email'];
      $password = $_POST['password'];
      $category = $_POST['category'];
      $courses = $_POST['courses'];
      $Education = $_POST['education'];
      $Description = $_POST['description'];
      $teacherUnique ="Select * from teacher where Email = '$email' ";
      $result = $conn->query($teacherUnique);
      if($result->num_rows >0){
        echo json_encode(array("StatusCode"=>400, "Message"=>"Account with This Email Already Exists."));
      }
      else{
        $sql = "INSERT INTO teacher (UserName, Email, Password,category,courseId, Education, Image, pdf_file_cv, description)
        VALUES ('$UserName','$email', '$password','$category','$courses','$Education','$path','$pathpdf', '$Description')";
        $result = $conn->query($sql);
        if($result){

          $teacherInsertedId = $conn->insert_id;
          $sql = "INSERT INTO users (UserType, UserId, Email, Password)
          VALUES (2, '$teacherInsertedId','$email', '$password')";
          $result = $conn->query($sql);
          echo json_encode(array("StatusCode"=>200, "Message"=>"Teacher Added Successfully."));
        }
        else{
          echo json_encode(array("StatusCode"=>300, "Message"=>"Something went wrong!"));
        }
      }
    }
  }
  else
  {
    echo 'invalid';
  }
}

?>
