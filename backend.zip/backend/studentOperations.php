<?php
include 'database.php';

if(isset($_POST['action']) && $_POST['action']=="getStudent"){
  // = "SELECT * FROM student";
  $getStudents ="SELECT * FROM student INNER JOIN courses ON  courses.courseId =  student.courseId";
  // $query = "SELECT * FROM student INNER JOIN assignment ON assignment.courseId = student.courseId
  //            INNER JOIN teacher
  //            ON teacher.courseId = assignment.courseId
  //            WHERE student.email = '".$studentEmail."'";
  $result = $conn->query($getStudents);
  $students= [];
  if($result->num_rows>0){
    while($row = $result->fetch_assoc()) {
      $students []= $row;
    }
    echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$students));
  }
  else{
    echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
  }
}

else if(isset($_POST['action']) && $_POST['action']=="getStudentData"){
  $studentId = $_POST['studentId'];
  $sql ="select * from student where student_id = '$studentId'";

  //$sql ="SELECT * FROM student INNER JOIN courses ON courses.courseId = teacher.courseId
                               //INNER JOIN teacher
                               //ON teacher.courseId = student.courseId
                              // WHERE student_id = '$studentId'";

  $result = $conn->query($sql);
  $students=[];
  if($result->num_rows>0){
    while($row = $result->fetch_assoc()) {
      $students []= $row;
    }
    echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found","Data"=>$students));
  }

  else{
    echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
  }

  }

  else if(isset($_POST['action']) && $_POST['action']=="DeleteStudentData"){
    $studentId = $_POST['studentId'];
    $sql ="DELETE  FROM student where student_id = '$studentId'";
    $result = $conn->query($sql);

    if ($result) {
      echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Deleted Successfully","Data" => $_POST['studentId'] ));
    }

    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }
  }

  else if(isset($_POST['action']) && $_POST['action']=="updateStudentData"){
    $studentId = $_POST['studentId'];
    $sql ="select * from student where student_id = '$studentId'";
    $result = $conn->query($sql);
    $students=[];
    if($result->num_rows>0){
      while($row = $result->fetch_assoc()) {
        $students []= $row;
      }
      echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found","Data"=>$students));
    }

    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }

    }



  else{
    $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt'); // valid extensions
    $path = '../images/uploads/'; // upload directory
    //$pathpdf = '../files/';

    $studentId = $_POST['studentid'];
    $username = $_POST['UserName'];
    $password = $_POST['password'];
    $education = $_POST['education'];
    $category = $_POST['category'];
    $courses = $_POST['courses'];
    $semester = $_POST['semester'];

    $img = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    //$pdf = $_FILES['pdf']['name'];
    //$pdftmp = $_FILES['pdf']['tmp_name'];
    $imgQuery = "";
    if($img!= ""){
      $imageFile = filesUpdate($img, $path, $tmp, $valid_extensions);
      $imgQuery = "Image ='$imageFile', ";
    }

    //$pdfQuery = "";
    //if($pdf!= ""){
      //$pdfFile = filesUpdate($pdf, $pathpdf, $pdftmp, $valid_extensions);
      //$pdfQuery = "Image ='$pdfFile', ";
    //}

    $sql="UPDATE student
    SET UserName = '$username',".$imgQuery." password = '$password', education= '$education',
    courseCategory = '$category', courseName = '$courses', semester = '$semester'
    WHERE student_id = '$studentId'";
    $result = $conn->query($sql);
    if($result){
      echo json_encode(array("StatusCode"=>200, "Message"=>"Updated Successfully"));
    }
    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"Something went wrong!"));
    }
  }


  function filesUpdate($path, $tmp, $valid_extensions){
    // get uploaded file's extension
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

    // can upload same image using rand function
    $final_file = rand(1000,1000000).$file;

    // check's valid format
    if(in_array($ext, $valid_extensions))
    {
      $path = $path.strtolower($final_file);
      $path = str_replace(' ', '', $path);

      if(move_uploaded_file($tmp,$path))
      {
        return $path;
      }
    }
    else
    {
      echo 'invalid';
    }
  }








?>
