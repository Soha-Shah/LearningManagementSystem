
<?php
  include 'database.php';
  session_start();
  if(isset($_POST['action']) && !empty($_POST['action'])) {
    $email = $_POST["emaily"];
    $password = $_POST["password"];
    $sql = " SELECT * FROM admin where Email = '$email' and `Password` = '$password' ";
    $result = $conn->query($sql);


    $teachers= [];
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        //$_SESSION['id']=$row['Id'];
        $teachers []= $row;
      }

      echo json_encode(array("StatusCode"=>"200", "Message"=>"Success"));
    }
    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"Invalid Email or Password!"));
    }

  }

  else if(isset($_POST['action']) && $_POST['action']=="getAdmin")  {
    //$email = $_POST["emaily"];
    //$password = $_POST["password"];
    $getStudents = "SELECT * FROM admin";
    $result = $conn->query($getStudents);
    $students= [];
    if($result->num_rows>0){
      while($row = $result->fetch_assoc()) {
        $students []= $row;
      }
      echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$students));
    }
    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }

  }
?>
