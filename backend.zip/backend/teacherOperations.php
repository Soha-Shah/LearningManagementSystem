<?php
  include 'database.php';
  if(isset($_POST['action']) && $_POST['action']=="getTeachers"){
    $getTeachers = "SELECT * FROM teacher";
    $result = $conn->query($getTeachers);
    $teachers= [];
    if($result->num_rows>0){
      while($row = $result->fetch_assoc()) {
        $teachers []= $row;
      }
      echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$teachers));
    }
    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }
  }

  else if(isset($_POST['action']) && $_POST['action']=="getTeacherData"){
    $teacherId = $_POST['teacherId'];
    $sql ="select * from teacher where teacher_id = '$teacherId'";
    $result = $conn->query($sql);
    $teachers=[];
    if($result->num_rows>0){
      while($row = $result->fetch_assoc()) {
        $teachers []= $row;
      }
      echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found","Data"=>$teachers));
    }

    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }

    }
    else if(isset($_POST['action']) && $_POST['action']=="getCourseCategories"){
      $CourseCategories = "SELECT * FROM course_category";
      $result = $conn->query($CourseCategories);
      $teachers= [];
      if($result->num_rows>0){
        while($row = $result->fetch_assoc()) {
          $teachers []= $row;
        }
        echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$teachers));
      }
      else{
        echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
      }
    }
    else if(isset($_POST['action']) && $_POST['action']=="getTeacherName"){
      $TeacherName = "SELECT * FROM teacher";
      $result = $conn->query($TeacherName);
      $teachers= [];
      if($result->num_rows>0){
        while($row = $result->fetch_assoc()) {
          $teachers []= $row;
        }
        echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$teachers));
      }
      else{
        echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
      }
    }
  else if(isset($_POST['action']) && $_POST['action']=="DeleteTeacherData"){
    $teacher_id = $_POST['teacher_id'];
    $sql =" DELETE  FROM teacher where teacher_id = '".$teacher_id."'";
    $result = $conn->query($sql);

    if ($result) {
      $sqlDelete ="DELETE  FROM users where UserId = '$teacherId' and UserType = '2'";
      $resultDelete = $conn->query($sqlDelete);
      if($resultDelete)
      {
        echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Deleted Successfully"));
      }
    }

    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }
  }
  else if(isset($_POST['action']) && $_POST['action']=="getUpdateTeacherData"){
    $teacherId = $_POST['teacherId'];
    $sql ="select * from teacher where teacher_id = '$teacherId'";
    $result = $conn->query($sql);
    $teachers=[];
    if($result->num_rows>0){
      while($row = $result->fetch_assoc()) {
        $teachers []= $row;
      }
      echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found","Data"=> $teachers));
    }

    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }
  }

  else{
    $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt'); // valid extensions
    $path = '../images/uploads/'; // upload directory
    $pathpdf = '../files/';

    $teacherId = $_POST['teacherID'];
    $username = $_POST['userName'];
    $password = $_POST['password'];
    $education = $_POST['education'];
    $description = $_POST['description'];

    $img = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    $pdf = $_FILES['pdf']['name'];
    $pdftmp = $_FILES['pdf']['tmp_name'];
    $imgQuery = "";
    if($img!= ""){
      $imageFile = filesUpdate($img, $path, $tmp, $valid_extensions);
      $imgQuery = "Image ='$imageFile', ";
    }

    $pdfQuery = "";
    if($pdf!= ""){
      $pdfFile = filesUpdate($pdf, $pathpdf, $pdftmp, $valid_extensions);
      $pdfQuery = "Image ='$pdfFile', ";
    }

    $sql="UPDATE teacher
    SET UserName = '$username',".$imgQuery." Password = '$password',".$pdfQuery." Education= '$education',
    description = '$description'
    WHERE teacher_id = '$teacherId'";
    $result = $conn->query($sql);
    if($result){
      echo json_encode(array("StatusCode"=>200, "Message"=>"Updated Successfully"));
    }
    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"Something went wrong!"));
    }
  }


  function filesUpdate($file, $path, $tmp, $valid_extensions){
    // get uploaded file's extension
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

    // can upload same image using rand function
    $final_file = rand(1000,1000000).$file;

    // check's valid format
    if(in_array($ext, $valid_extensions))
    {
      $path = $path.strtolower($final_file);
      $path = str_replace(' ', '', $path);

      if(move_uploaded_file($tmp,$path))
      {
        return $path;
      }
    }
    else
    {
      echo 'invalid';
    }
  }
  // else if(isset($_POST['action']) && $_POST['action']=="UpdateTeacher"){
  //   $teacherId = $_POST['teacherId'];
  //     $username = $_POST['username'];
  //       $email = $_POST['email'];
  //         $password = $_POST['password'];
  //           $education = $_POST['education'];
  //             $image = $_POST['image'];
  //               $pdf = $_POST['pdf'];
  //                  $description = $_POST['description'];
  //
  //             $sql="UPDATE teacher
  //          SET UserName = '$username', Email='$email', Password = '$password', Education= '$education', Image = '$image', pdf_file_cv= '  $pdf',
  //          description = '$description'
  //          WHERE teacher_id = '$teacherId'";
  //
  //   $result = $conn->query($sql);
  //   $teachers=[];
  //   if($result->num_rows>0){
  //     while($row = $result->fetch_assoc()) {
  //       $teachers []= $row;
  //     }
  //     echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Updated Successfully"));
  //   }
  //
  //   else{
  //     echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
  //   }
  //
  //
  //
  // // echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$teacherId));
  // }








?>
