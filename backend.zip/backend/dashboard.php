<?php
include 'database.php';
if(isset($_POST['action']) && $_POST['action']=="countTeachers"){
  //$getTeachers = "SELECT COUNT(*) FROM teacher";

  $result = mysqli_query($conn, "SELECT teacher_id FROM teacher ORDER BY teacher_id");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));
}

else if(isset($_POST['action']) && $_POST['action']=="pendingTeachers"){


  $result = mysqli_query($conn, "SELECT teacher_id FROM pending_teacher ORDER BY teacher_id");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}

else if(isset($_POST['action']) && $_POST['action']=="enrollStudents"){


  $result = mysqli_query($conn, "SELECT student_id FROM student  ORDER BY student_id");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}

else if(isset($_POST['action']) && $_POST['action']=="registerStudent"){


  $result = mysqli_query($conn, "SELECT student_id FROM student_registration  ORDER BY student_id");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}

else if(isset($_POST['action']) && $_POST['action']=="registerAdmin"){


  $result = mysqli_query($conn, "SELECT Id FROM admin  ORDER BY Id");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}

else if(isset($_POST['action']) && $_POST['action']=="courseCategory"){


  $result = mysqli_query($conn, "SELECT courseCategoryId FROM course_category  ORDER BY courseCategoryId ");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}


else if(isset($_POST['action']) && $_POST['action']=="course"){


  $result = mysqli_query($conn, "SELECT courseId FROM courses  ORDER BY courseId ");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}


else if(isset($_POST['action']) && $_POST['action']=="users"){


  $result = mysqli_query($conn, "SELECT Id FROM users  ORDER BY Id ");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}


else if(isset($_POST['action']) && $_POST['action']=="webStudents"){


  $result = mysqli_query($conn, "SELECT student_id FROM student WHERE courseCategory = 1  ORDER BY student_id ");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}


else if(isset($_POST['action']) && $_POST['action']=="androidStudents"){


  $result = mysqli_query($conn, "SELECT student_id FROM student WHERE courseCategory = 2  ORDER BY student_id ");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}

else if(isset($_POST['action']) && $_POST['action']=="graphicStudents"){


  $result = mysqli_query($conn, "SELECT student_id FROM student WHERE courseCategory = 3  ORDER BY student_id ");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));

}













 ?>
