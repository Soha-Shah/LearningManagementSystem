<?php
include 'database.php';
$valid_extensions = array('jpeg','jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt'); // valid extensions
$path = '../images/uploads/'; // upload directory


if(isset($_FILES['image']))
{
  $img = $_FILES['image']['name'];
   //$img_type = $_FILES['image']['type'];
  $tmp = $_FILES['image']['tmp_name'];



  // get uploaded file's extension
  $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));


  // can upload same image using rand function
  $final_image = rand(1000,1000000).$img;


  // check's valid format
  if(in_array($ext, $valid_extensions))
  {
    $path = $path.strtolower($final_image);

    $path = str_replace(' ', '', $path);


    if(move_uploaded_file($tmp,$path))
    {
      $courseName = $_POST['courseName'];
      $courseCategory = $_POST['courseCategory'];
    //  $teacherName = $_POST['teacherName'];
      $Description = $_POST['description'];
      $courseUnique ="Select * from courses where courseName = '$courseName'";
      $result = $conn->query($courseUnique);
      if($result->num_rows >0){
        echo json_encode(array("StatusCode"=>400, "Message"=>"Already Course Exist"));
      }
      else{
        $sql = "INSERT INTO courses (courseName, courseCategory, thumbnail, description)
        VALUES ('$courseName','$courseCategory','$path', '$Description')";
        $course = $conn->query($sql);
        if($course){

           echo json_encode(array("StatusCode"=>200, "Message"=>"Course Added Successfully"));
        }
        else{
          echo json_encode(array("StatusCode"=>300, "Message"=>"Something went wrong!"));
        }
      }
   }
 }
 else
  {
   echo 'invalid';
  }
}

?>
