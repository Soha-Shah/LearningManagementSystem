<?php
include 'database.php';

if(isset($_POST['action']) && $_POST['action']=="getBook"){
  $teacherEmail = $_POST["teacherEmail"];
  $query = "SELECT * FROM teacher INNER JOIN courses ON courses.courseId = teacher.courseId
             INNER JOIN book ON book.courseId = teacher.courseId
             WHERE teacher.Email = '".$teacherEmail."'";
  //$getCourses = "SELECT * from book as B inner join teacher as T On T.courseId = B.courseId where T.Email = '".$teacherEmail."'";
  //$getStudents = "SELECT * FROM book";
  $result = $conn->query($query);
  $students= [];
  if($result->num_rows>0){
    while($row = $result->fetch_assoc()) {
      $students []= $row;
    }
    echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$students));
  }
  else{
    echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
  }
}

else if(isset($_POST['action']) && $_POST['action']=="DeleteBookData"){
  $bookId = $_POST['bookId'];
  $sql ="DELETE FROM book where book_id = '$bookId'";
  $result = $conn->query($sql);

  if ($result) {
    echo json_encode(array("StatusCode"=>"200", "Message"=>"Book Deleted Successfully"));
  }

  else{
    echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
  }
}




?>
