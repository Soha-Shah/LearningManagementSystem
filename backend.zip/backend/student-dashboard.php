<?php
include 'database.php';
if(isset($_POST['action']) && $_POST['action']=="countCourses"){
  $countCourses = $_POST['countCourses'];
  //$getTeachers = "SELECT COUNT(*) FROM teacher";

  $result = mysqli_query($conn, "SELECT COUNT(courseId) FROM student WHERE email ='$countCourses'");
  $num_rows = mysqli_num_rows($result);


     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));
}
?>
