<?php
include 'database.php';



$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt'); // valid extensions
$path = '../images/uploads/'; // upload directory
//$pathpdf = '../../learningManagementSystem/files/';
if($_FILES['image'])
{
  $img = $_FILES['image']['name'];
  $tmp = $_FILES['image']['tmp_name'];

  //$pdf = $_FILES['resume']['name'];
  //$pdftmp = $_FILES['resume']['tmp_name'];

  // get uploaded file's extension
  $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
  //$extpdf = strtolower(pathinfo($pdf, PATHINFO_EXTENSION));

  // can upload same image using rand function
  $final_image = rand(1000,1000000).$img;
  //$final_pdf = rand(1000,1000000).$pdf;

  // check's valid format
  if(in_array($ext, $valid_extensions))
  {
    $path = $path.strtolower($final_image);
    //$pathpdf = $pathpdf.strtolower($final_pdf);

    if(move_uploaded_file($tmp,$path))
    {
      $UserName = $_POST['UserName'];
      $email = $_POST['email'];
      $password = $_POST['password'];
      $Education = $_POST['education'];
      $category = $_POST['category'];
      $courses = $_POST['courses'];
      $semester = $_POST['semester'];
      //$education = $_POST['education'];
      $studentUnique ="Select * from student where email = '$email' ";
      $result = $conn->query($studentUnique);
      if($result->num_rows >0){
        echo json_encode(array("StatusCode"=>400, "Message"=>"Account with This Email Already Exists."));
      }
      else{
        $sql = "INSERT INTO student (UserName,email,password, education,courseCategory,courseId,semester,image)
        VALUES ('$UserName','$email', '$password','$Education','$category','$courses','$semester','$path')";
        $result = $conn->query($sql);
        if($result){
         $studentInsertedId = $conn->insert_id;
          $sql = "INSERT INTO users (UserType, UserId, Email, Password)
          VALUES (1, '$studentInsertedId','$email', '$password')";
          $result = $conn->query($sql);
          echo json_encode(array("StatusCode"=>200, "Message"=>"Student Enroll Successfully."));
        }
        else{
          echo json_encode(array("StatusCode"=>300, "Message"=>"Something went wrong!"));
        }
      }
    }
  }
  else
  {
    echo 'invalid';
  }
}


?>
