<?php
  include 'database.php';
  if(isset($_POST['action']) && $_POST['action']=="getcoursesDataByEnrollment"){
     $studentEmail = $_POST['studentEmail'];
    $getCourses ="SELECT * from courses as C inner join student as S On S.courseId = C.courseId where S.email = '$studentEmail'";
    $result = $conn->query($getCourses);
    $courses= [];
    if($result->num_rows>0){
      while($row = $result->fetch_assoc()) {
        $courses []= $row;
      }
      echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$courses));
    }
    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }

  }
  ?>






 ?>
