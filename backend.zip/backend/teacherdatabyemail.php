<?php
include 'database.php';

if(isset($_POST['action'])){

 $teacherEmail = $_POST['teacherEmail'];
 $sql ="select * from teacher where Email = '$teacherEmail'";
 $result = $conn->query($sql);
 $teachers=[];
 if($result->num_rows>0){
   while($row = $result->fetch_assoc()) {
     $teachers []= $row;
   }
   echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found","Data"=>$teachers));
 }
 else{
  echo json_encode(array("StatusCode"=>"200", "Message"=>"No Data Found"));
 }

}



 ?>
