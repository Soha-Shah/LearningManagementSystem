<?php
include 'database.php';
if(isset($_POST['action']) && $_POST['action']=="getenrollAssignments"){
  $studentEmail = $_POST['studentEmail'];
  //$getStudents = "SELECT * from courses as C inner join student as S On S.courseId = C.courseId where S.email = '$studentEmail'";
  $query = "SELECT * FROM student INNER JOIN assignment ON assignment.courseId = student.courseId
             INNER JOIN teacher
             ON teacher.courseId = assignment.courseId
             WHERE student.email = '".$studentEmail."'";
  //$query = "SELECT * from book as B inner join student as S On S.courseId = B.courseId where S.email = '".$studentEmail."'";
  $result = $conn->query($query);
  $students= [];
  if($result->num_rows>0){
    while($row = $result->fetch_assoc()) {
      $students []= $row;
    }
    echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$students));
  }
  else{
    echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
  }
}

 ?>
