<?php
include 'database.php';



$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt'); // valid extensions
//$path = '../images/uploads/'; // upload directory
$pathpdf = '../files/';
if($_FILES['resume'])
{
  //$img = $_FILES['image']['name'];
  //$tmp = $_FILES['image']['tmp_name'];

  $pdf = $_FILES['resume']['name'];
  $pdftmp = $_FILES['resume']['tmp_name'];

  // get uploaded file's extension
  //$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
  $extpdf = strtolower(pathinfo($pdf, PATHINFO_EXTENSION));

  // can upload same image using rand function
  //$final_image = rand(1000,1000000).$img;
  $final_pdf = rand(1000,1000000).$pdf;

  // check's valid format
  if(in_array($extpdf, $valid_extensions))
  {
    //$path = $path.strtolower($final_image);
    $pathpdf = $pathpdf.strtolower($final_pdf);

    if(move_uploaded_file($pdftmp,$pathpdf))
    {
      $title = $_POST['title'];
      $course = $_POST['course'];
      $category = $_POST['category'];
      $date = $_POST['date'];

      //$education = $_POST['education'];
      $assignmentUnique ="Select * from assignment where title = '$title' and courseCategory = '$category'";
      $result = $conn->query($assignmentUnique);
      if($result->num_rows >0){
        echo json_encode(array("StatusCode"=>400, "Message"=>"Assignment with This Category Already Exists."));
      }
      else{
        $sql = "INSERT INTO assignment (title,courseCategory,courseId,date,pdf)
        VALUES ('$title', '$category','$course','$date','$pathpdf')";
        $result = $conn->query($sql);
        if($result){
          //$studentInsertedId = $conn->insert_id;
          //$sql = "INSERT INTO users (UserType, UserId, Email, Password)
          //VALUES (1, '$studentInsertedId','$email', '$password')";
          //$result = $conn->query($sql);
          echo json_encode(array("StatusCode"=>200, "Message"=>"Assignment Added Successfully."));
        }
        else{
          echo json_encode(array("StatusCode"=>300, "Message"=>"Something went wrong!"));
        }
      }
    }
  }
  else
  {
    echo 'invalid';
  }
}


?>
