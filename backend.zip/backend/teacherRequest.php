<?php
  include 'database.php';
  if(isset($_POST['action']) && $_POST['action']=="getTeachersRequest"){
    $getTeacherRequest = "SELECT * FROM pending_teacher";
    $result = $conn->query($getTeacherRequest);
    $teachers= [];
    if($result->num_rows>0){
      while($row = $result->fetch_assoc()) {
        $teachers []= $row;
      }
      echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$teachers));
    }
    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }
  }

  else if(isset($_POST['action']) && $_POST['action']=="DeleteTeacherData"){
    $teacherId = $_POST['teacherId'];
    $sql ="DELETE  FROM pending_teacher where teacher_id = '$teacherId'";
    $result = $conn->query($sql);

    if ($result) {
      echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Deleted Successfully","Data" => $_POST['teacherId'] ));
    }

    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }
  }



  else if(isset($_POST['action']) && $_POST['action']=="getTeacherData"){
    $teacherId = $_POST['teacherId'];
    $sql ="select * from pending_teacher where teacher_id = '$teacherId'";
    $result = $conn->query($sql);
    $teachers=[];
    if($result->num_rows>0){
      while($row = $result->fetch_assoc()) {
        $teachers []= $row;
      }
      echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found","Data"=>$teachers));
    }

    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }

    }




  // echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$teacherId));



  else if(isset($_POST['action']) && $_POST['action']=="getTeacherData"){
    $teacherId = $_POST['teacherId'];
    $sql ="select * from pending_teacher where teacher_id = '$teacherId'";
    $result = $conn->query($sql);
    //$teachers=[];
    if($result){

     echo json_encode(array("StatusCode"=>"200", "Message"=>"Data Found"));
    }

    else{
      echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
    }

    }





  ?>
