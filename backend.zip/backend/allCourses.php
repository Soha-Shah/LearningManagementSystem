<?php
include 'database.php';
if(isset($_POST['action']) && $_POST['action']=="getTeacherCourses"){
 //$teacherEmail = $_POST['teacherEmail'];
 //$getCourses = "SELECT * from courses as C inner join teacher as T On T.courseId = C.courseId where T.Email = '".$teacherEmail."'";
    //$getCourses = "SELECT * FROM courses";
   $getCourses = "SELECT * FROM courses INNER JOIN teacher ON  courses.courseId =  teacher.courseId";
  $result = $conn->query($getCourses);
  $courses= [];
  if($result->num_rows>0){
  while($row = $result->fetch_assoc()) {
    $courses []= $row;
   }
   echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$courses));
 }
 else{
  echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
}
}




// else if(isset($_POST['action']) && $_POST['action']=="getCourses"){
//  //$CourseCategories = "SELECT * FROM courses";
//  $CourseCategories = "SELECT courses.courseName,courses.thumbnail,teacher.UserName,
//                FROM courses
//                INNER JOIN teacher
//                ON courses.teacher_id = teacher.teacher_id";
//  $result = $conn->query($CourseCategories);
//  $teachers= [];
//  if($result->num_rows>0){
//    while($row = $result->fetch_assoc()) {
//      $teachers []= $row;
//    }
//    echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$teachers));
//  }
//  else{
//    echo json_encode(array("StatusCode"=>300, "Message"=>"No Data Found"));
//  }
// }

?>
