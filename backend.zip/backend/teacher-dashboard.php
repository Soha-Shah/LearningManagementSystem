<?php
include 'database.php';
if(isset($_POST['action']) && $_POST['action']=="countCourse"){
  $countCourse = $_POST['countCourse'];
  $result = mysqli_query($conn, "SELECT COUNT(courseId) FROM student WHERE email ='$countCourse'");
  $num_rows = mysqli_num_rows($result);
  //$getTeachers = "SELECT COUNT(*) FROM teacher";
  //$query ="select COUNT(student_id) from student INNER JOIN teacher ON teacher.courseId = student.courseId";

//$query = "SELECT * FROM teacher INNER JOIN courses ON courses.courseId = teacher.courseId
          //   INNER JOIN student student_id
            // ON  student.courseId = teacher.courseId
            // WHERE teacher.Email = $countStudent";



     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));
}



else if(isset($_POST['action']) && $_POST['action']=="countStudent"){
  $totalStudent = $_POST['totalStudent'];
  
  $result = mysqli_query($conn,"SELECT COUNT(student.student_id), student.courseCategory
 FROM student INNER JOIN teacher ON student.courseId=teacher.courseId
   WHERE teacher.Email ='".$totalStudent."'");
  $num_rows = mysqli_num_rows($result);
  //$getTeachers = "SELECT COUNT(*) FROM teacher";
  //$query ="select COUNT(student_id) from student INNER JOIN teacher ON teacher.courseId = student.courseId";

//$query = "SELECT * FROM teacher INNER JOIN courses ON courses.courseId = teacher.courseId
          //   INNER JOIN student student_id
            // ON  student.courseId = teacher.courseId
            // WHERE teacher.Email = $countStudent";



     echo json_encode(array("StatusCode"=>200, "Message"=>"Data Found", "Data"=>$num_rows));
}

?>
